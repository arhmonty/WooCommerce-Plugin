<?php

require_once plugin_dir_path(__FILE__) . '../../abstract/class-wc-abstract-custom-gateway.php';

class WC_Gateway_Custom_Hosted extends WC_Abstract_Custom_Gateway
{
    /**
     * @var Custom_Payment_Processor_Hosted
     */
    protected $payment_processor;
    public function __construct()
    {
        $this->id                = 'hosted_card_gateway';
        $this->method_title      = __('MontyPay - Hosted Payment', 'custom-card-payment');
        $this->method_description = __('Collects card details in a hosted payment page', 'custom-card-payment');
        parent::__construct();
        $this->has_fields        = true; // we’re adding our own form fields


        // instantiate your processor
        $this->payment_processor = new Custom_Payment_Processor_Hosted(
            $this->get_option('merchant_key'),
            $this->get_option('merchant_pass')
        );
        add_action('wp_enqueue_scripts', array($this, 'enqueue_checkout_styles'));
    }


    public function enqueue_checkout_styles()
    {
        if (is_checkout() && ! is_wc_endpoint_url()) {
            wp_enqueue_style(
                'montypay-block-styles',
                plugin_dir_url(__FILE__) . '../../assets/css/block.css',
                array(),
                '1.0'
            );
        }
    }
    public function init_form_fields()
    {

        $this->form_fields = [
            'enabled' => [
                'title'   => __('Enable/Disable', 'custom-card-payment'),
                'type'    => 'checkbox',
                'label'   => __('Enable this payment method', 'custom-card-payment'),
                'default' => 'no'
            ],
            'merchant_key' => [
                'title'       => __('Merchant Key', 'custom-card-payment'),
                'type'        => 'text',
                'description' => __('Provided by your payment gateway', 'custom-card-payment'),
                'desc_tip'    => true,
            ],
            'merchant_pass' => [
                'title'       => __('Merchant Password', 'custom-card-payment'),
                'type'        => 'password',
                'description' => __('Provided by your payment gateway', 'custom-card-payment'),
                'desc_tip'    => true,
            ],

            'title' => [
                'title'       => __('Title', 'custom-card-payment'),
                'type'        => 'text',
                'default'     => __('Credit/Debit Card', 'custom-card-payment'),
                'desc_tip'    => true,
            ],
            'description' => [
                'title'       => __('Description', 'custom-card-payment'),
                'type'        => 'textarea',
                'default'     => __('Pay with your credit card', 'custom-card-payment'),
                'desc_tip'    => true,
            ],
            'show_visa' => array(
                'title'       => __('Show Visa Icon', 'custom-card-payment'),
                'type'        => 'checkbox',
                'label'       => __('Display the Visa logo in checkout', 'custom-card-payment'),
                'default'     => 'yes',
            ),
            'show_mastercard' => array(
                'title'       => __('Show MasterCard Icon', 'custom-card-payment'),
                'type'        => 'checkbox',
                'label'       => __('Display the MasterCard logo in checkout', 'custom-card-payment'),
                'default'     => 'yes',
            ),
            'show_amex' => array(
                'title'       => __('Show AmEx Icon', 'custom-card-payment'),
                'type'        => 'checkbox',
                'label'       => __('Display the AmEx logo in checkout', 'custom-card-payment'),
                'default'     => 'yes',
            ),
            'iframe_enabled' => [
                'title'   => 'Inline Iframe Payments',
                'type'    => 'checkbox',
                'label'   => 'Enable inline iframe checkout (no redirect)',
                'default' => 'no',
            ],
            'recurring_enabled' => [
                'title'   => 'Enable Recurring Payments',
                'type'    => 'checkbox',
                'label'   => 'Enable Recurring Payments',
                'default' => 'no',
            ],

        ];
    }
    /**
     * Return gateway icons (displayed after the title).
     *
     * @return string HTML for the icons.
     */
    public function get_icon()
    {
        $icons = '';

        if ('yes' === $this->get_option('show_visa', 'no')) {
            $icons .= sprintf(
                '<img src="%s" alt="%s" style="width:36px;height:auto;margin-left:8px;vertical-align:middle;">',
                'https://cdn.shopify.com/shopifycloud/checkout-web/assets/c1.en/assets/visa.sxIq5Dot.svg',
                esc_attr__('Visa', 'your-text-domain')
            );
        }

        if ('yes' === $this->get_option('show_mastercard', 'no')) {
            $icons .= sprintf(
                '<img src="%s" alt="%s" style="width:36px;height:auto;margin-left:4px;vertical-align:middle;">',
                'https://cdn.shopify.com/shopifycloud/checkout-web/assets/c1.en/assets/master.CzeoQWmc.svg',
                esc_attr__('MasterCard', 'your-text-domain')
            );
        }

        if ('yes' === $this->get_option('show_amex', 'no')) {
            $icons .= sprintf(
                '<img src="%s" alt="%s" style="width:36px;height:auto;margin-left:4px;vertical-align:middle;">',
                'https://cdn.shopify.com/shopifycloud/checkout-web/assets/c1.en/assets/american_express.C3z4WB9r.svg',
                esc_attr__('AmEx', 'your-text-domain')
            );
        }

        return $icons;
    }


    // ----------------------------------------------------------------RECURRING OPTIONS------------------------------------------------------------------------------------
    public function process_admin_options()
    {
        // 1) Let WooCommerce save its own gateway options first.
        parent::process_admin_options();
        $Logger = wc_get_logger();

        $errors   = [];
        $existing = get_option('wc_montypay_recurring_schedules', []);
        if (! is_array($existing)) {
            $existing = [];
        }

        // 2) Handle any deletions
        $to_delete = ! empty($_POST['deleted_schedules']) && is_array($_POST['deleted_schedules'])
            ? array_map('sanitize_text_field', wp_unslash($_POST['deleted_schedules']))
            : [];

        if ($to_delete) {
            foreach ($to_delete as $schedule_id) {
                // Build MontyPay DELETE payload
                $to_sign = $schedule_id . $this->get_option('merchant_pass');
                $reversed = strrev($to_sign);
                $upper    = strtoupper($reversed);
                $hash     = md5($upper);

                $payload = [
                    'action'      => 'DELETE_SCHEDULE',
                    'client_key'  => $this->get_option('merchant_key'),
                    'schedule_id' => $schedule_id,
                    'hash'        => $hash,
                ];

                // debug, if you need to inspect exactly what’s sent
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    $Logger->error('MontyPay Delete Payload: ' . print_r($payload, true));
                }

                $response = wp_safe_remote_post('https://api.montypay.com/post', [
                    'body'    => $payload,
                    'timeout' => 15,
                ]);

                if (is_wp_error($response)) {
                    $errors[] = sprintf(
                        'Failed to delete schedule "%s": HTTP error: %s',
                        esc_html($schedule_id),
                        $response->get_error_message()
                    );
                    continue;
                }

                $body = wp_remote_retrieve_body($response);
                $json = json_decode($body, true);

                if (empty($json['result']) || $json['result'] !== 'SUCCESS') {
                    $msg = $json['error_message'] ?? $body;
                    $errors[] = sprintf(
                        'MontyPay delete error for "%s": %s',
                        esc_html($schedule_id),
                        esc_html($msg)
                    );
                    continue;
                }

                // On success, remove from our local array
                $existing = array_filter($existing, function ($row) use ($schedule_id) {
                    return (isset($row['schedule_id']) && $row['schedule_id'] === $schedule_id)
                        ? false
                        : true;
                });
            }
        }

        // 3) Now handle creations & re-keep any existing ones
        $saved_schedules = [];

        if (! empty($_POST['recurring_schedules']) && is_array($_POST['recurring_schedules'])) {
            foreach ($_POST['recurring_schedules'] as $row) {
                // sanitize every field
                $row = array_map('sanitize_text_field', $row);

                // If this row already came back with a schedule_id, keep it
                if (! empty($row['schedule_id'])) {
                    $saved_schedules[] = $row;
                    continue;
                }

                // Otherwise it’s a brand-new one → validate required
                if (
                    empty($row['name'])
                    || empty($row['interval_length'])
                    || empty($row['interval_unit'])
                    || empty($row['payments_count'])
                ) {
                    $errors[] = 'New schedule is missing required fields.';
                    continue;
                }

                // enforce length & numeric constraints
                if (mb_strlen($row['name']) > 100) {
                    $errors[] = 'Schedule name must be 100 characters or fewer.';
                    continue;
                }
                $interval_length = intval($row['interval_length']);
                if ($interval_length < 1) {
                    $errors[] = 'Interval length must be at least 1.';
                    continue;
                }
                if (! in_array($row['interval_unit'], ['day', 'month'], true)) {
                    $errors[] = 'Interval unit must be "day" or "month".';
                    continue;
                }
                $payments_count = intval($row['payments_count']);
                if ($payments_count < 1) {
                    $errors[] = 'Payments count must be at least 1.';
                    continue;
                }
                if ($row['interval_unit'] === 'month') {
                    $dom = intval($row['day_of_month']);
                    if ($dom < 1 || $dom > 31) {
                        $errors[] = 'Day of month must be between 1 and 31.';
                        continue;
                    }
                }

                // build MontyPay CREATE payload
                $payload = [
                    'action'          => 'CREATE_SCHEDULE',
                    'client_key'      => $this->get_option('merchant_key'),
                    'name'            => $row['name'],
                    'interval_length' => $interval_length,
                    'interval_unit'   => $row['interval_unit'],
                    'payments_count'  => $payments_count,
                ];
                if ($row['interval_unit'] === 'month') {
                    $payload['day_of_month'] = intval($row['day_of_month']);
                }
                if (! empty($row['delays'])) {
                    $payload['delays'] = intval($row['delays']);
                }
                // signature
                $payload['hash'] = md5(strtoupper(strrev($this->get_option('merchant_pass'))));

                $response = wp_safe_remote_post('https://api.montypay.com/post', [
                    'body'    => $payload,
                    'timeout' => 30,
                ]);

                if (is_wp_error($response)) {
                    $errors[] = 'HTTP error for "' . esc_html($row['name']) . '": ' . $response->get_error_message();
                    continue;
                }

                $body = wp_remote_retrieve_body($response);
                $json = json_decode($body, true);

                if (! empty($json['result']) && $json['result'] === 'SUCCESS' && ! empty($json['id'])) {
                    // success!
                    $row['schedule_id'] = sanitize_text_field($json['id']);
                    $saved_schedules[]  = $row;
                } else {
                    $msg = $json['error_message'] ?? 'Invalid response';
                    if (! empty($json['errors'])) {
                        $parts = [];
                        foreach ($json['errors'] as $err) {
                            $parts[] = '[' . intval($err['error_code']) . '] ' . sanitize_text_field($err['error_message']);
                        }
                        $msg .= ' (Details: ' . implode('; ', $parts) . ')';
                    }
                    $errors[] = 'MontyPay error for "' . esc_html($row['name']) . '": ' . esc_html($msg);
                }
            }
        }

        // 4) Merge any surviving existing schedules that weren’t re-posted
        foreach ($existing as $old) {
            // skip any that were re-added or newly created
            $keep = true;
            foreach ($saved_schedules as $s) {
                if (isset($s['schedule_id'], $old['schedule_id']) && $s['schedule_id'] === $old['schedule_id']) {
                    $keep = false;
                    break;
                }
            }
            if ($keep) {
                $saved_schedules[] = $old;
            }
        }

        // 5) Persist them all
        update_option('wc_montypay_recurring_schedules', $saved_schedules);

        // 6) Show any errors
        if (! empty($errors)) {
            add_action('admin_notices', function () use ($errors) {
                foreach ($errors as $err) {
                    echo '<div class="error"><p>' . esc_html($err) . '</p></div>';
                }
            });
        }
    }

    public function admin_options()
    {
        echo '<h2>' . esc_html($this->get_method_title()) . '</h2>';
        echo wp_kses_post(wpautop($this->get_method_description()));

        // WooCommerce already injected <form>… settings_fields()…
        echo '<table class="form-table">';
        $this->generate_settings_html();
        echo '</table>';

        // inject your schedules table inline:
        echo '<table class="form-table"><tr valign="top">
          <th class="titledesc">Recurring Schedules</th>
          <td>';
        include plugin_dir_path(__FILE__) . './recurring/recurring-schedules-form.php';
        echo    '</td></tr></table>';
        $callback_url    = add_query_arg('wc-api', 'wc_montypay_callback', home_url('/'));
        echo '<p><strong>' . esc_html__('Callback Url:', 'woocommerce-gateway-wpgfull') . '</strong> '
            . esc_url($callback_url)
            . '</p>';
    }
    // ----------------------------------------------------------------CLASSIC CHECKOUT------------------------------------------------------------------------------------

    /**
     * Output credit card form fields on classic checkout
     */
    public function payment_fields()
    {
        if ('yes' === $this->get_option('iframe_enabled', 'no')) {
            echo '<div id="montypay-iframe-container" style="margin:20px 0;"></div>';
        } else {
?>
            <div class="MontyPayLogo">
                <label><?php _e('Powered By', 'custom-card-payment'); ?></label>
                <img
                    src="https://montypaydev.com/global_assets/images/MontyPayLogo.png"
                    alt="<?php esc_attr_e('MontyPay Logo', 'custom-card-payment'); ?>"
                    class="MontyPayLogo MontyPayLogo-classic" />
            </div>

<?php }
    }




    /**
     * Process payment on classic checkout
     */

    public function process_payment($order_id)
    {
        // 1) Get the URL
        $response     = $this->payment_processor->get_redirect_url($order_id);
        $redirect_url = $response['redirect_url'] ?? '';

        // 2) Read your iframe toggle
        $settings       = get_option('woocommerce_hosted_card_gateway_settings', []);
        $iframe_enabled = (! empty($settings['iframe_enabled']) && 'yes' === $settings['iframe_enabled']);

        // 3) If iframe ON, inject the blocking+iframe JS
        if ($redirect_url && $iframe_enabled) {
            WC()->session->set('montypay_iframe_url', $redirect_url);


            // Tell WC we succeeded but stay on the page
            return [
                'result'   => 'success',
                'redirect' => '',
            ];
        }

        // 4) Normal redirect fallback
        if ($redirect_url) {
            return [
                'result'   => 'success',
                'redirect' => $redirect_url,
            ];
        }

        // 5) Final fallback: error
        wc_add_notice(__('Payment processing failed. Please try again.', 'custom-card-payment'), 'error');
        return [
            'result'   => 'fail',
            'redirect' => wc_get_checkout_url(),
        ];
    }
}
