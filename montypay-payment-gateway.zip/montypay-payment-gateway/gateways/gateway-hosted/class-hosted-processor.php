<?php
if (!defined('ABSPATH')) exit;
require_once plugin_dir_path(__FILE__) . '../../abstract/class-wc-abstract-custom-gateway.php';

class Custom_Payment_Processor_Hosted
{
    private $merchant_key;
    private $merchant_pass;


    public $currencies_3dotexponent = ['BHD', 'JOD', 'KWD', 'OMR', 'TND'];
    public $currencies_noexponent = ['VND', 'ISK', 'UGX'];

    public function __construct($merchant_key, $merchant_pass)
    {
        $this->merchant_key  = $merchant_key;
        $this->merchant_pass = $merchant_pass;
    }


    public function get_hash($order_id, $amount, $currency)
    {


        $str_to_hash = $order_id . $amount . $currency . __('Payment Order # ', 'woocommerce') . $order_id . __(' in the store ', 'woocommerce') . $this->merchant_pass;
        $hash = sha1(md5(strtoupper($str_to_hash)));


        return $hash;
    }


    public function process_payment($order_id)
    {

        $Logger = wc_get_logger();
        $Logger->info('Processing payment for order ID: ' . $order_id, ['source' => 'hosted-payment']);

        // Implement your payment processing logic here
        $response = $this->get_redirect_url($order_id);
        $settings = get_option('woocommerce_hosted_card_gateway_settings', []);
        $iframe_enabled = (
            ! empty($settings['iframe_enabled']) &&
            'yes' === $settings['iframe_enabled']
        );
        // Redirect to the payment page
        if (isset($response['redirect_url']) && $response['redirect_url']) {
            if ($iframe_enabled) {
                // Inline iframe flow
                WC()->session->set('montypay_iframe_url', $response['redirect_url']);
                return ['result' => 'success', 'redirect' => ''];
            }
            return array(
                'result'   => 'success',
                'redirect' => $response['redirect_url'],
            );
        } else {
            // If redirect URL is not available, handle the code here
            // For example, you can add an error notice and redirect back to checkout
            // wc_add_notice(__('Payment processing failed. Please try again.', 'your-text-domain'), 'error');
            return array(
                'result'   => 'fail',
                'redirect' => wc_get_checkout_url(),
            );
        }
    }
    public function get_redirect_url($order_id)
    {

        $order = wc_get_order($order_id);
        $Logger = new WC_Logger();

        // --- Enforce "one recurring only" rule ---
        $settings = get_option('woocommerce_hosted_card_gateway_settings', []);
        $recurring_enabled = (
            ! empty($settings['recurring_enabled']) &&
            'yes' === $settings['recurring_enabled']
        );
        if ($recurring_enabled) {
            $rec_count   = 0;
            $normal_count = 0;
            foreach ($order->get_items() as $item) {
                /** @var WC_Order_Item_Product $item */
                $pid = $item->get_product_id();
                $pid      = $item->get_product_id();
                if (get_post_meta($pid, '_montypay_recurring_enabled', true) === 'yes') {
                    $rec_count++;
                } else {
                    $normal_count++;
                }
            }

            if ($rec_count > 1 || ($rec_count === 1 && $normal_count > 0)) {
                $msg = 'You may purchase only one recurring subscription at a time (with no other products in the cart). '
                    . 'Either remove the extra items or disable recurring in the gateway settings.';

                wc_add_notice($msg, 'error');
                $Logger->add(
                    "❌ recurring rule violation: rec_count={$rec_count}, normal_count={$normal_count}",
                    ['source' => 'montypay']
                );

                return ['result' => 'fail', 'redirect' => ''];
            }
        }


        // ------------------------------------------

        $customer = array(
            'name' => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
            'email' => $order->get_billing_email(),
        );

        $billing_address = array(
            'country' => $order->get_billing_country() ? $order->get_billing_country() : 'NA',
            'city' => $order->get_billing_city() ? $order->get_billing_city() : 'NA',
            'address' => $order->get_billing_address_1() ? $order->get_billing_address_1() : 'NA',
            'zip' => $order->get_billing_postcode() ? $order->get_billing_postcode() : 'NA',
        );
        if ($order->get_billing_state()) {
            $billing_address['state'] = $order->get_billing_state();
        }
        if ($order->get_billing_phone()) {
            $billing_address['phone'] = $order->get_billing_phone();
        }

        $amount = number_format($order->get_total(), 2, '.', '');
        if (in_array(get_woocommerce_currency(), $this->currencies_noexponent)) {
            $amount = number_format($order->get_total(), 0, '.', '');
        } elseif (in_array(get_woocommerce_currency(), $this->currencies_3dotexponent)) {

            $value = round($order->get_total(), 2);
            $amount = number_format($value, 3, '.', '');
        }
        $currency = get_woocommerce_currency();



        $order_json = array(
            'number' => "$order_id",
            'description' => __('Payment Order # ', 'woocommerce') . $order_id . __(' in the store ', 'woocommerce'),
            'amount' => $amount, //may troubles
            'currency' => $currency,
        );


        $request = [
            'merchant_key' => $this->merchant_key,
            'operation'    => 'purchase', //m subs purchase
            'order'        => $order_json,
            'customer'     => $customer,
            'billing_address' => $billing_address,
            'success_url' =>  $order->get_checkout_order_received_url(),
            'cancel_url'   => $order->get_view_order_url(), //
            'hash'         => $this->get_hash($order_id, $amount, $currency),
        ];

        // If exactly one recurring item → set recurring_init + schedule_id
        if ($recurring_enabled && $rec_count === 1) {
            $request['recurring_init'] = true;

            // find that single product's schedule_id
            foreach ($order->get_items() as $item) {
                /** @var WC_Order_Item_Product $item */
                $pid = $item->get_product_id();
                if (get_post_meta($pid, '_montypay_recurring_enabled', true) === 'yes') {
                    $request['schedule_id'] = sanitize_text_field(
                        get_post_meta($pid, '_montypay_recurring_schedule_id', true)
                    );
                    break;
                }
            }
        }
        $iframe_enabled = (
            ! empty($settings['iframe_enabled']) &&
            'yes' === $settings['iframe_enabled']
        );
        if ($iframe_enabled) {
            $request['url_target'] = '_parent';
        }
        $result = $this->callAPI("https://checkout.montypay.com/api/v1/session", $request, $order_id);
        $Logger = new WC_Logger();
        $Logger->add('montypay', 'Result: ' . json_encode($result));

        if (isset($result->redirect_url) && $result->redirect_url) {

            $order = wc_get_order($result->order_id);



            return ['order_id' => $order_id, 'redirect_url' => $result->redirect_url];
        } else {

            return ['result' => $result->result, 'error_message' => $result->error_message, 'errors' => $result->errors];
        }
    }
    public function callAPI($url, $postFields = null, $orderId = null)
    {
        // Prepare JSON payload
        $body = wp_json_encode($postFields);

        // Send request via WP HTTP API
        $response = wp_remote_post($url, [
            'headers'     => [
                'Content-Type' => 'application/json',
            ],
            'body'        => $body,
            'timeout'     => 5,    // max seconds to wait for the request to complete
            'connect_timeout' => 5, // max seconds to establish connection
            'blocking'    => true,
            'redirection' => 5,
            'sslverify'   => true,
        ]);

        // Initialize logger
        $logger = wc_get_logger();

        // Log request
        $logger->info("MontyPay Request: {$body}", ['source' => 'hosted-payment']);

        // Handle WP errors
        if (is_wp_error($response)) {
            $error_msg = $response->get_error_message();
            $logger->error("MontyPay WP_Error: {$error_msg}", ['source' => 'hosted-payment']);
            return null;
        }

        // Extract response code and body
        $http_code = wp_remote_retrieve_response_code($response);
        $res_body  = wp_remote_retrieve_body($response);

        // Log response
        $logger->info("MontyPay Response ({$http_code}): {$res_body}", ['source' => 'hosted-payment']);

        if ($http_code !== 200) {
            $logger->warning("MontyPay non-200 HTTP code: {$http_code}", ['source' => 'hosted-payment']);
        }

        // Decode and return JSON
        return json_decode($res_body);
    }
}


add_action('woocommerce_thankyou', function ($order_id) {
    if (isset($_GET['payment']) && $_GET['payment'] === 'declined') {
        echo '<div class="woocommerce-error" style="margin:20px 0;">Your order ' . $order_id . ' is received but your payment was declined. Please try a different card or contact your bank.</div>';
    }
});
add_action('woocommerce_update_options_payment_gateways_montypay', function () {
    if (isset($_POST['recurring_schedules'])) {
        $cleaned = [];
        foreach ($_POST['recurring_schedules'] as $row) {
            $row = array_map('sanitize_text_field', $row);
            if (!empty($row['name']) && !empty($row['interval_length']) && !empty($row['interval_unit']) && !empty($row['payments_count'])) {
                $cleaned[] = $row;
            }
        }
        update_option('wc_montypay_recurring_schedules', $cleaned);
    }
});
require_once __DIR__ . '/recurring/class-montypay-recurring-product-meta.php';

add_action('wp_enqueue_scripts', 'wc_montypay_enqueue_iframe_js', 20);
function wc_montypay_enqueue_iframe_js()
{
    if (! is_checkout()) {
        return;
    }

    // 1) Pull in the live gateway
    $gateways = WC()->payment_gateways->get_available_payment_gateways();
    if (empty($gateways['hosted_card_gateway'])) {
        return;
    }
    $gateway = $gateways['hosted_card_gateway'];

    // 2) Only if iframe is on
    if ('yes' !== $gateway->get_option('iframe_enabled', 'no')) {
        return;
    }

    // 3) Build the public URL using plugins_url() + your main plugin file
    //    This makes sure WP knows the correct plugin folder to use.
    $js_url = plugins_url('assets/js/montypay-inline.js', __DIR__ . '/../../montypay-gateway.php');

    // 4) For cache-busting, build the real file path and use filemtime()
    $js_path = plugin_dir_path(__DIR__ . '/../../montypay-gateway.php') . 'assets/js/montypay-inline.js';
    $ver     = file_exists($js_path) ? filemtime($js_path) : false;

    // 5) Enqueue and localize
    wp_enqueue_script(
        'montypay-inline-js',
        $js_url,
        ['jquery', 'wc-checkout'],
        $ver,
        true
    );
    wp_localize_script('montypay-inline-js', 'WC_MontyPay', [
        'ajax_url'   => admin_url('admin-ajax.php'),
        'gateway_id' => $gateway->id,
    ]);
}

add_action('woocommerce_hosted_card_gateway_payment_fields', function () {
    echo '<div id="montypay-iframe-container" style="margin:20px 0;"></div>';
});
add_action('wp_ajax_get_montypay_iframe_url', 'get_mpi_url');
add_action('wp_ajax_nopriv_get_montypay_iframe_url', 'get_mpi_url');
function get_mpi_url()
{
    if (! WC()->session) {
        wp_send_json_error('no_session');
    }
    $url = WC()->session->get('montypay_iframe_url');
    if ($url) {
        wp_send_json_success(['url' => esc_url_raw($url)]);
    }
    wp_send_json_error('no_url');
}
add_filter( 'woocommerce_gateway_icon', function( $icon, $gateway_id ) {
    // Only target your hosted_card_gateway
    if ( 'hosted_card_gateway' !== $gateway_id ) {
        return $icon;
    }

    // Pull saved settings
    $settings = get_option( 'woocommerce_hosted_card_gateway_settings', [] );

    $html = '';

    if ( ! empty( $settings['show_visa'] ) && 'yes' === $settings['show_visa'] ) {
        $html .= '<img src="https://cdn.shopify.com/shopifycloud/checkout-web/assets/c1.en/assets/visa.sxIq5Dot.svg"'
               . ' alt="Visa" style="width:36px;height:auto;margin-left:8px;vertical-align:middle;" />';
    }

    if ( ! empty( $settings['show_mastercard'] ) && 'yes' === $settings['show_mastercard'] ) {
        $html .= '<img src="https://cdn.shopify.com/shopifycloud/checkout-web/assets/c1.en/assets/master.CzeoQWmc.svg"'
               . ' alt="MasterCard" style="width:36px;height:auto;margin-left:4px;vertical-align:middle;" />';
    }

    if ( ! empty( $settings['show_amex'] ) && 'yes' === $settings['show_amex'] ) {
        $html .= '<img src="https://cdn.shopify.com/shopifycloud/checkout-web/assets/c1.en/assets/american_express.C3z4WB9r.svg"'
               . ' alt="AmEx" style="width:36px;height:auto;margin-left:4px;vertical-align:middle;" />';
    }

    // Return your icons (WooCommerce will echo them immediately after the title)
    return $html;
}, 10, 2 );
