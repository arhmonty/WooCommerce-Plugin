<?php
// File: admin/recurring-schedules-form.php
if ( ! defined( 'ABSPATH' ) ) exit;

// Only show if shop-wide recurring is enabled
if ('no' === $this->get_option( 'recurring_enabled', 'no' )) {
    echo '<p><em>Recurring payments are currently disabled.</em></p>';
    return;
}

// Load and normalize schedules
$raw = get_option( 'wc_montypay_recurring_schedules', [] );
if ( ! is_array( $raw ) ) {
    $raw = [];
}
$defaults = [
    'schedule_id'     => '',
    'name'            => '',
    'interval_length' => '',
    'interval_unit'   => 'day',
    'day_of_month'    => '',
    'payments_count'  => '',
];
$schedules = [];
foreach ( $raw as $row ) {
    if ( ! is_array( $row ) ) {
        continue;
    }
    if ( empty( $row['schedule_id'] ) && ! empty( $row['id'] ) ) {
        $row['schedule_id'] = $row['id'];
    }
    if ( empty( $row['schedule_id'] ) ) {
        continue;
    }
    $schedules[] = array_merge( $defaults, $row );
}

// Build product‐map: schedule_id => [ items => [ {id,title,url}… ], count => N ]
$product_map = [];
foreach ( $schedules as $sched ) {
    $sid = $sched['schedule_id'];
    $q = new WP_Query( [
        'post_type'      => 'product',
        'posts_per_page' => 3,
        'meta_key'       => '_montypay_recurring_schedule_id',
        'meta_value'     => $sid,
        'fields'         => 'ids',
    ] );
    if ( $q->found_posts > 0 ) {
        $links = [];
        foreach ( $q->posts as $pid ) {
            $links[] = [
                'id'    => $pid,
                'title' => get_the_title( $pid ),
                'url'   => get_edit_post_link( $pid ),
            ];
        }
        $product_map[ $sid ] = [
            'items' => $links,
            'count' => intval( $q->found_posts ),
        ];
    }
}
?>
<style>
#recurring-schedules-notice .notice { margin-bottom:12px; }
#recurring-schedules-table { width:auto; table-layout:fixed; border-collapse:collapse; margin:12px 0; }
#recurring-schedules-table th, #recurring-schedules-table td { border:1px solid #e1e1e1; padding:6px 8px; text-align:center; vertical-align:middle; }
#recurring-schedules-table th { background:#f7f7f7; font-weight:600; }
#recurring-schedules-table tbody tr:nth-child(even) { background:#fcfcfc; }
#recurring-schedules-table input, #recurring-schedules-table select { width:100%; box-sizing:border-box; padding:4px 6px; font-size:14px; }
.button.remove-row { background:#f0f0f0; border-color:#ddd; color:#333; }
.button.remove-row:hover { background:#e0e0e0; }
button.delete-row { background:#dc3232!important; border-color:#dc3232!important; color:#fff!important; }
button.delete-row:hover { background:#b22222!important; border-color:#b22222!important; }
#add-schedule-row { margin-top:8px; }
</style>

<div id="recurring-schedules-notice"></div>

<table class="widefat fixed striped" id="recurring-schedules-table">
  <thead>
    <tr>
      <th>Schedule ID</th>
      <th>Name</th>
      <th>Interval Length</th>
      <th>Interval Unit</th>
      <th>Day of Month</th>
      <th>Payments Count</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ( $schedules as $i => $row ) : ?>
    <tr>
      <td>
        <span><?= esc_html( $row['schedule_id'] ); ?></span>
        <input type="hidden" name="recurring_schedules[<?= $i ?>][schedule_id]" value="<?= esc_attr( $row['schedule_id'] ); ?>">
      </td>
      <td>
        <span><?= esc_html( $row['name'] ); ?></span>
        <input type="hidden" name="recurring_schedules[<?= $i ?>][name]" value="<?= esc_attr( $row['name'] ); ?>">
      </td>
      <td>
        <span><?= esc_html( $row['interval_length'] ); ?></span>
        <input type="hidden" name="recurring_schedules[<?= $i ?>][interval_length]" value="<?= esc_attr( $row['interval_length'] ); ?>">
      </td>
      <td>
        <span><?= ucfirst( esc_html( $row['interval_unit'] ) ); ?></span>
        <input type="hidden" name="recurring_schedules[<?= $i ?>][interval_unit]" value="<?= esc_attr( $row['interval_unit'] ); ?>">
      </td>
      <td>
        <span><?= esc_html( $row['day_of_month'] ); ?></span>
        <input type="hidden" name="recurring_schedules[<?= $i ?>][day_of_month]" value="<?= esc_attr( $row['day_of_month'] ); ?>">
      </td>
      <td>
        <span><?= esc_html( $row['payments_count'] ); ?></span>
        <input type="hidden" name="recurring_schedules[<?= $i ?>][payments_count]" value="<?= esc_attr( $row['payments_count'] ); ?>">
      </td>
      <td>
        <button type="button"
                class="button delete-row"
                data-schedule-id="<?= esc_attr( $row['schedule_id'] ); ?>">
          Delete
        </button>
      </td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table>

<button type="button" class="button" id="add-schedule-row">Add Schedule</button>

<script>
(function(){
  const MAX         = 5;
  const productMap  = <?= wp_json_encode( $product_map ); ?>;
  const noticeWrap  = document.getElementById('recurring-schedules-notice');
  const tbody       = document.querySelector('#recurring-schedules-table tbody');
  const form        = document.querySelector('form');
  const addBtn      = document.getElementById('add-schedule-row');

  function showError(html) {
    noticeWrap.innerHTML = '<div class="notice notice-error inline"><p>' + html + '</p></div>';
  }

  addBtn.addEventListener('click', () => {
    noticeWrap.innerHTML = '';
    const count = tbody.querySelectorAll('tr').length;
    if ( count >= MAX ) {
      showError('You may only have up to ' + MAX + ' schedules.');
      return;
    }
    if ( tbody.querySelector('input[name$="[schedule_id]"][value=""]') ) {
      return;
    }
    const idx = count;
    tbody.insertAdjacentHTML('beforeend', `
      <tr>
        <td>
          <input type="text" name="recurring_schedules[${idx}][schedule_id_visible]" readonly>
          <input type="hidden" name="recurring_schedules[${idx}][schedule_id]" value="">
        </td>
        <td><input type="text" name="recurring_schedules[${idx}][name]" maxlength="100" required></td>
        <td><input type="number" name="recurring_schedules[${idx}][interval_length]" min="1" required></td>
        <td>
          <select name="recurring_schedules[${idx}][interval_unit]">
            <option value="day">Day</option>
            <option value="month">Month</option>
          </select>
        </td>
        <td><input type="number" name="recurring_schedules[${idx}][day_of_month]" min="1" max="31"></td>
        <td><input type="number" name="recurring_schedules[${idx}][payments_count]" min="1" required></td>
        <td><button type="button" class="button remove-row">Remove</button></td>
      </tr>
    `);
  });

  document.addEventListener('click', function(e) {
    if ( e.target.classList.contains('remove-row') ) {
      noticeWrap.innerHTML = '';
      e.target.closest('tr').remove();
      return;
    }
    if ( e.target.classList.contains('delete-row') ) {
      noticeWrap.innerHTML = '';
      const id = e.target.dataset.scheduleId;
      const info = productMap[id] || { items: [], count: 0 };
      if ( info.count > 0 ) {
        let links = info.items.map(function(p){
          return '<a href="' + p.url + '" target="_blank">' + p.title + '</a>';
        }).join(', ');
        if ( info.count > info.items.length ) {
          links += ' and ' + (info.count - info.items.length) + ' more…';
        }
        showError(
          'Cannot delete schedule <strong>' + id + '</strong> — it is assigned to ' +
          info.count + ' product(s): ' + links
        );
        return;
      }
      if ( confirm('Really delete schedule ' + id + '?' ) ) {
        const input = document.createElement('input');
        input.type  = 'hidden';
        input.name  = 'deleted_schedules[]';
        input.value = id;
        form.appendChild(input);
        e.target.closest('tr').remove();
      }
    }
  });
})();
</script>
