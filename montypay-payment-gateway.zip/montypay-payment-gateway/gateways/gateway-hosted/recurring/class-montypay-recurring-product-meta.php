<?php
// File: admin/class-montypay-recurring-product-meta.php
if (! defined('ABSPATH')) exit;

// 1) Add the metabox
add_action('add_meta_boxes', function () {
    add_meta_box(
        'montypay-recurring',
        'MontyPay Recurring',
        'montypay_render_recurring_meta_box',
        'product',
        'side',
        'default'
    );
});

/**
 * Render the metabox HTML + JS
 */
function montypay_render_recurring_meta_box($post)
{
    wp_nonce_field('montypay_save_recurring_meta', 'montypay_recurring_nonce');

    $wc_opts = get_option('woocommerce_montypay_settings', []);
    if (empty($wc_opts['recurring_enabled']) || $wc_opts['recurring_enabled'] !== 'yes') {
        echo '<p><em>Recurring payments are disabled shop-wide.</em></p>';
        return;
    }

    $enabled   = get_post_meta($post->ID, '_montypay_recurring_enabled', true) === 'yes';
    $saved_id  = get_post_meta($post->ID, '_montypay_recurring_schedule_id', true);
    $raw       = get_option('wc_montypay_recurring_schedules', []);
    $schedules = is_array($raw) ? $raw : [];

    // Checkbox
    printf(
        '<p><label><input type="checkbox" id="montypay_recurring_enabled" name="montypay_recurring_enabled" %s> Enable Recurring for this Product</label></p>',
        checked(true, $enabled, false)
    );

    // Dropdown
    echo '<p><label for="montypay_recurring_schedule_id">Schedule:</label><br>';
    echo '<select id="montypay_recurring_schedule_id" name="montypay_recurring_schedule_id">';
    echo '<option value="">— Select a Schedule —</option>';
    foreach ($schedules as $s) {
        if (empty($s['schedule_id'])) {
            continue;
        }
        printf(
            '<option value="%s" %s>%s</option>',
            esc_attr($s['schedule_id']),
            selected($saved_id, $s['schedule_id'], false),
            esc_html($s['name'])
        );
    }
    echo '</select></p>';

    // Placeholder for inline errors
    echo '<div id="montypay-recurring-error" style="margin-top:4px;"></div>';

    // JS enforcement
?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const cb = document.getElementById('montypay_recurring_enabled');
            const sel = document.getElementById('montypay_recurring_schedule_id');
            const error = document.getElementById('montypay-recurring-error');

            function clearError() {
                error.innerHTML = '';
            }

            cb.addEventListener('change', () => {
                clearError();
                if (cb.checked && !sel.value) {
                    error.innerHTML = '<div class="notice notice-error inline"><p>Please select a schedule before enabling recurring.</p></div>';
                    cb.checked = false;
                }
            });

            sel.addEventListener('change', () => {
                clearError();
            });
        });
    </script>
<?php
}

// 2) Save on product save
add_action('save_post_product', function ($post_id, $post) {
    if (! isset($_POST['montypay_recurring_nonce'])) {
        return;
    }
    if (! wp_verify_nonce($_POST['montypay_recurring_nonce'], 'montypay_save_recurring_meta')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if ($post->post_type !== 'product') {
        return;
    }

    // Save enabled flag
    $enabled = ! empty($_POST['montypay_recurring_enabled']) ? 'yes' : 'no';
    update_post_meta($post_id, '_montypay_recurring_enabled', $enabled);

    if ($enabled === 'yes' && ! empty($_POST['montypay_recurring_schedule_id'])) {
        $schedule_id = sanitize_text_field(wp_unslash($_POST['montypay_recurring_schedule_id']));
        update_post_meta($post_id, '_montypay_recurring_schedule_id', $schedule_id);
    } else {
        // Recurring was turned off → remove the assigned schedule
        delete_post_meta($post_id, '_montypay_recurring_schedule_id');
    }
}, 10, 2);
