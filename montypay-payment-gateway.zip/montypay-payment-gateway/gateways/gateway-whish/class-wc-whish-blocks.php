<?php
use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

if (!class_exists('Custom_Whish_Blocks_Integration')) {
    class Custom_Whish_Blocks_Integration extends AbstractPaymentMethodType {
        protected $name = 'whish_card_gateway';
        protected $settings;

        public function initialize() {
            $this->settings = get_option('woocommerce_whish_card_gateway_settings', []);
        }

        public function is_active() {
            return isset($this->settings['enabled']) && wc_string_to_bool($this->settings['enabled']);
        }

        public function get_payment_method_script_handles() {
            wp_register_style(
                'whish-card-blocks-style',
                plugins_url('../assets/css/whish-block.css', dirname(__FILE__)), // use unique file or name
                [],
                '1.0.0'
            );
            wp_enqueue_style('whish-card-blocks-style');

            // Enqueue shared utils first
wp_register_script(
    'shared-utils',
    plugins_url('../assets/js/shared-utils.js', dirname(__FILE__)),
    [ 'wc-blocks-registry', 'wc-settings', 'wp-element', 'wp-html-entities' ],
    '1.0.0',
    true
);

    
wp_register_script(
    'whish-card-blocks',
    plugins_url('../assets/js/whish.js', dirname(__FILE__)),
    [ 'shared-utils' ],
    '1.0.0',
    true
);

    
            return ['whish-card-blocks'];
        }
    
      

        public function get_payment_method_data() {
            return [
                'title' => $this->settings['title'] ?? __('Pay Online with Whsih', 'custom-card-payment'),
                'description' => $this->settings['description'] ?? __('Pay Online With Whsih', 'custom-card-payment'),
                'supports' => ['products'],
                // Add CSS class for targeting
                'cssClass' => 'custom-card-gateway'
            ];
        }
    }
}