<?php
if (!defined('ABSPATH')) exit;
require_once plugin_dir_path(__FILE__) . '../../abstract/class-wc-abstract-custom-gateway.php';

class Custom_Payment_Processor_Whish {
    private $terminal_id;
    private $branch_id;
    private $ApiKey;
    private $TenantId;

    private $merchant_pass;
  

    public $currencies_3dotexponent = ['BHD', 'JOD', 'KWD', 'OMR', 'TND'];
    public $currencies_noexponent = [ 'VND', 'ISK', 'UGX'];

    public function __construct($terminal_id, $branch_id , $ApiKey, $TenantId , $merchant_pass) {
        $this->terminal_id  = $terminal_id;
        $this->branch_id = $branch_id;
        $this->ApiKey = $ApiKey;
        $this->TenantId = $TenantId;  
        $this->merchant_pass = $merchant_pass;

        add_action('woocommerce_api_wc_montypay_success_callback', array($this, 'check_ipn_response_success'));
        add_action('woocommerce_api_wc_montypay_fail_callback', array($this, 'check_ipn_response_fail'));
    }
    private function get_hash($order_id, $amount, $currency, $tip = '0.0') {
      $merchant_pass = $this->merchant_pass;
  
      $input = strtoupper($order_id . $amount . $currency . $tip . $merchant_pass);
  
      $md5 = md5($input);
      $sha1 = sha1($md5);
  
      return $sha1;
  }
  
    

    public function process_payment($order_id) {

      $Logger = wc_get_logger();
       $Logger->add('montypay', 'Processing payment for order ID: ' . $order_id);
  
      // Implement your payment processing logic here
      $response = $this->get_redirect_url($order_id);
      
      // Redirect to the payment page
      if(isset($response['redirect_url']) && $response['redirect_url'] ){
        return array(
            'result'   => 'success',
            'redirect' => $response['redirect_url'],
        );
      }
      else{
      // If redirect URL is not available, handle the code here
          // For example, you can add an error notice and redirect back to checkout
          // wc_add_notice(__('Payment processing failed. Please try again.', 'your-text-domain'), 'error');
          return array(
              'result'   => 'fail',
              'redirect' => wc_get_checkout_url(),
          );
      }
    }
    public function get_redirect_url($order_id){

        $order = wc_get_order($order_id);
        
       
    
        $billing_address = array(
            'country' => $order->get_billing_country() ? $order->get_billing_country() : 'NA',
            'state' => $order->get_billing_state() ? $order->get_billing_state() : 'NA',
            'city' => $order->get_billing_city() ? $order->get_billing_city() : 'NA',
            'address' => $order->get_billing_address_1() ? $order->get_billing_address_1() : 'NA',
            'zip' => $order->get_billing_postcode() ? $order->get_billing_postcode() : 'NA',
            'phone' => $order->get_billing_phone() ? $order->get_billing_phone() : 'NA',
        );
    
    
        $amount = number_format($order->get_total(), 2, '.', '');
        if (in_array(get_woocommerce_currency(), $this->currencies_noexponent)) {
          $amount = number_format($order->get_total(), 0, '.', '');
        }elseif (in_array(get_woocommerce_currency(), $this->currencies_3dotexponent)) {
    
          $value = round($order->get_total(), 2);
          $amount = number_format($value, 3, '.', '');
    
        }
        $currency = get_woocommerce_currency();
      
    
    
        $body = [
          "TransactionCurrency" => $currency,
          "TransactionAmount" => $amount, // or your dynamic amount
          "Tip" => "0.0", // or your dynamic tip
          "TerminalId" => $this->terminal_id,
          "BranchId" => $this->branch_id,
          "OrderId" => "$order_id",
          "Description" => __('Payment Order # ', 'woocommerce') . $order_id,
          "SuccessUrl" => $order->get_checkout_order_received_url(),
          "FailedUrl" => $order->get_view_order_url(),
          "SuccessCallbackUrl" => home_url('/wc-api/wc_montypay_success_callback'),
          "FailureCallbackUrl" => home_url('/wc-api/wc_montypay_fail_callback'),
          "Hash" => $this->get_hash($order_id, $amount, $currency, '0.0'), // includes tip
      
          "customer" => [
              "Name" => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
              "PhoneNumber" => $billing_address['phone'],
              "PhoneCountryCode" => "961", // you can make this dynamic
              "Email" => $order->get_billing_email(),
              "BillingAddress" => [
                  "Address" => $billing_address['address'],
                  "Country" => $billing_address['country'],
                  "State" => $billing_address['state'],
                  "City" => $billing_address['city'],
                  "Zip" => $billing_address['zip']
              ]
          ]
      ];
      
    
       
       
      $result = $this->callAPI(
        "https://mm-core.montypay.com/api/v1/transaction/checkout", $body, $order_id
    );

    $Logger = new WC_Logger();
    $Logger->add('montypay', 'Result: ' . json_encode($result));

    // Check if the message is 'Success' and url exists
    if (isset($result->message) && strtolower($result->message) === 'success' && isset($result->data->url)) {
        return [
            'order_id' => $order_id,
            'redirect_url' => $result->data->url
        ];
    } else {
        return [
            'result' => $result->result ?? 'fail',
            'error_message' => $result->error_message ?? 'Unknown error',
            'errors' => $result->errors ?? null
        ];
    }
}
public function callAPI( $url, $postFields = null, $orderId = null ) {
    // Prepare JSON payload
    $body   = wp_json_encode( $postFields );
    $logger = wc_get_logger();

    // Log the outgoing request
    $logger->info( 'MontyPay Request: ' . $body, [ 'source' => 'whish-payment' ] );

    // Send via WP HTTP API with headers, 5-second timeouts
    $response = wp_remote_post( $url, [
        'headers'         => [
            'Content-Type' => 'application/json',
            'Api-Key'      => $this->ApiKey,
            'Tenant'       => $this->TenantId,
        ],
        'body'            => $body,
        'timeout'         => 5,
        'connect_timeout' => 5,
        'blocking'        => true,
        'redirection'     => 5,
        'sslverify'       => true,
    ] );

    // Handle transport errors
    if ( is_wp_error( $response ) ) {
        $logger->error( 'MontyPay WP_Error: ' . $response->get_error_message(), [ 'source' => 'whish-payment' ] );
        return null;
    }

    // Extract HTTP status and body
    $http_code = wp_remote_retrieve_response_code( $response );
    $res_body  = wp_remote_retrieve_body( $response );

    // Log the response
    $logger->info( "MontyPay Response ({$http_code}): {$res_body}", [ 'source' => 'whish-payment' ] );
    if ( $http_code !== 200 ) {
        $logger->warning( 'MontyPay HTTP Code: ' . $http_code, [ 'source' => 'whish-payment' ] );
    }

    // Return decoded JSON
    return json_decode( $res_body );
}



    public function check_ipn_response_success() {
        $Logger = new WC_Logger();
        $Logger->add('montypay', 'IPN Success Callback: ' . json_encode($_GET));
    
        // Handle the success callback here
        // You can update the order status, send emails, etc.
        // Example: update_post_meta($order_id, '_payment_status', 'completed');
        //get the order id from the $_GET array

        if (!isset($_GET['orderid'])) {
            $Logger->add('montypay', 'Order ID not found in the request.');
            return;
        }

        $order_id = $_GET['orderid'];
        $order = wc_get_order($order_id);
        $order->update_status('processing', __('Payment received via Whish Money.', 'woocommerce'));
        $order->add_order_note(__('Payment received via Whish Money.', 'woocommerce'));
    }


    public function check_ipn_response_fail() {
        $Logger = new WC_Logger();
        $Logger->add('montypay', 'IPN Fail Callback: ' . json_encode($_GET));


        if (!isset($_GET['orderid'])) {
            $Logger->add('montypay', 'Order ID not found in the request.');
            return;
        }
    
        // Handle the fail callback here
        // You can update the order status, send emails, etc.
        // Example: update_post_meta($order_id, '_payment_status', 'failed');
        //get the order id from the $_GET array
        $order_id = $_GET['orderid'];
        $order = wc_get_order($order_id);
        $order->update_status('failed', __('Payment failed via Whish Money.', 'woocommerce'));
        $order->add_order_note(__('Payment failed via Whish Money.', 'woocommerce'));
    }
    
 


     
}












add_action('woocommerce_thankyou', function($order_id) {
    if (isset($_GET['payment']) && $_GET['payment'] === 'declined') {
        echo '<div class="woocommerce-error" style="margin:20px 0;">Your order ' . $order_id . ' is received but your payment was declined. Please try a different card or contact your bank.</div>';
    }
});