<?php

require_once plugin_dir_path(__FILE__) . '../../abstract/class-wc-abstract-custom-gateway.php';

class WC_Gateway_Custom_ApplePay extends WC_Abstract_Custom_Gateway
{
    /**
     * @var Custom_Payment_Processor_ApplePay
     */
    protected $payment_processor;

    public function __construct()
    {
        $this->id = 'apple_pay_gateway';
        $this->method_title = __('MontyPay - Apple Pay', 'custom-card-payment');
        $this->method_description = __('Collects card details in a Apple Pay payment page', 'custom-card-payment');
        parent::__construct();
        $this->has_fields = true; // we're adding our own form fields
        $this->icon = 'https://montypaydev.com/global_assets/images/apple.png';
        
        // Set default title if not set in settings
        if (empty($this->title)) {
            $this->title = __('Apple Pay', 'custom-card-payment');
        }

        // Add AJAX handler for cart items
        add_action('wp_ajax_get_cart_items', array($this, 'get_cart_items'));
        add_action('wp_ajax_nopriv_get_cart_items', array($this, 'get_cart_items'));

        // instantiate your processor
        $this->payment_processor = new Custom_Payment_Processor_ApplePay(
            $this->get_option('merchant_key'),
            $this->get_option('merchant_pass'),
            $this->get_option('merchant_identifier'),
            $this->get_option('private_key'),
            $this->get_option('certificate'),
            $this->get_option('merchant_domain'),
        );
        add_action('wp_enqueue_scripts', array($this, 'enqueue_checkout_styles'));
        $this->init_form_fields();
        $this->init_settings();
        add_action('wp_enqueue_scripts', [$this, 'enqueue_applepay_classic_assets']);

        // Enqueue necessary data for JavaScript
        // In WC_Gateway_Custom_ApplePay constructor
        // In class constructor
        add_action('rest_api_init', [$this, 'register_rest_routes']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_apple_pay_data']);
        add_action('wp_ajax_save_merchant_session', 'save_merchant_session');
        add_action('wp_ajax_nopriv_save_merchant_session', 'save_merchant_session');
        if (is_admin() && !function_exists('wp_handle_upload')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        add_filter('upload_mimes', function ($mimes) {
            // Allow Apple Pay Merchant Identity certificate
            $mimes['pem'] = 'application/x-x509-ca-cert';
            // Allow private key files
            $mimes['key'] = 'application/octet-stream';
            return $mimes;
        });
        add_action('wp_enqueue_scripts', [$this, 'enqueue_eruda_debugger']);
        
        // Add filter to customize payment method display in order details
        add_filter('woocommerce_order_get_payment_method_title', array($this, 'modify_payment_method_title'), 10, 2);
        
        // Add visual indicator in order list
        add_action('manage_shop_order_posts_custom_column', array($this, 'show_payment_method_in_order_list'), 10, 2);
    }

    public function enqueue_eruda_debugger()
    {
        // Only load Eruda on the checkout page
        if (is_checkout() && !is_wc_endpoint_url()) {
            // 1) Load Eruda
            wp_enqueue_script(
                'eruda',
                'https://cdn.jsdelivr.net/npm/eruda',
                [],
                null,
                true
            );
            // 2) Initialize it immediately after
            wp_add_inline_script(
                'eruda',
                'eruda.init();',
                'after'
            );
        }
    }

    public function register_rest_routes()
    {
        register_rest_route('montypay/v1', '/validate', [
            'methods' => 'POST',
            'callback' => [$this, 'handle_rest_validation'],
            'permission_callback' => '__return_true'
        ]);
        register_rest_route('montypay/v1', '/apple_pay_process', [
            'methods' => 'POST',
            'callback' => [$this, 'handle_apple_pay'],
            'permission_callback' => '__return_true'
        ]);
    }

    public function save_merchant_session()
    {
        $body = file_get_contents('php://input');
        $data = json_decode($body, true); // Parse the JSON data from the client-side

        // Save the merchant session in a file (you can modify the path as needed)
        $file_path = WP_CONTENT_DIR . '/uploads/apple-pay-merchant-session.json';

        // Convert data back to JSON and save to file
        file_put_contents($file_path, json_encode($data, JSON_PRETTY_PRINT));

        // Respond back to client (optional)
        wp_send_json_success(['message' => 'Merchant session saved successfully.']);
    }

    public function enqueue_checkout_styles()
    {
        if (is_checkout() && !is_wc_endpoint_url()) {
            wp_enqueue_style(
                'montypay-block-styles',
                plugin_dir_url(__FILE__) . '../../assets/css/applepay.css',
                array(),
                '1.0'
            );
        }
    }

    public function init_form_fields()
    {
        parent::init_form_fields();

        // Override the title field with Apple Pay specific default
        $this->form_fields['title']['default'] = 'Apple Pay';
        $this->form_fields['description']['default'] = __('Pay securely with Apple Pay using Touch ID or Face ID', 'custom-card-payment');

        $this->form_fields = array_merge($this->form_fields, [
            'merchant_identifier' => [
                'title' => __('Apple Pay Merchant ID', 'custom-card-payment'),
                'type' => 'text',
                'description' => __('Your Apple Merchant Identifier', 'custom-card-payment'),
                'default' => '',
                'desc_tip' => true,
            ],
            'supported_networks' => [
                'title' => __('Supported Networks', 'custom-card-payment'),
                'type' => 'multiselect',
                'options' => [
                    'amex' => 'American Express',
                    'visa' => 'Visa',
                    'masterCard' => 'MasterCard',
                    'discover' => 'Discover',
                ],
                'default' => ['amex', 'visa', 'masterCard'],
            ],
            'merchant_domain' => [
                'title' => __('Merchant Domain', 'custom-card-payment'),
                'type' => 'text',
                'description' => __('Your Merchant Domain', 'custom-card-payment'),
                'default' => '',
                'desc_tip' => true,
            ],
            'certificate_pem' => [
                'title' => __('Apple Pay Certificate (PEM)', 'custom-card-payment'),
                'type' => 'textarea',
                'description' => __('Paste the contents of your Apple Pay merchant-identity certificate here (PEM format).', 'custom-card-payment'),
                'default' => '',
            ],
            'private_key_pem' => [
                'title' => __('Apple Pay Private Key (PEM)', 'custom-card-payment'),
                'type' => 'textarea',
                'description' => __('Paste the contents of your private key here (PEM format).', 'custom-card-payment'),
                'default' => '',
            ],
        ]);
    }

    public function process_admin_options()
    {
        // 1) Save the textarea fields into the _pem options:
        parent::process_admin_options();

        // 2) Certificate PEM → file
        $cert_pem = $this->get_option('certificate_pem');
        if (!empty($cert_pem)) {
            // sanitize: strip any HTML tags, but preserve line breaks
            $cert_pem = sanitize_textarea_field($cert_pem);

            // decide where to write it
            $upload_dir = wp_upload_dir();
            $path = trailingslashit($upload_dir['basedir']) . 'apple-pay-certs/';
            if (!is_dir($path)) {
                wp_mkdir_p($path);
            }
            $cert_file = $path . 'merchant.pem';
            file_put_contents($cert_file, $cert_pem);

            // store the path for runtime use
            $this->update_option('certificate', $cert_file);
        }

        // 3) Private-key PEM → file
        $key_pem = $this->get_option('private_key_pem');
        if (!empty($key_pem)) {
            $key_pem = sanitize_textarea_field($key_pem);

            $upload_dir = wp_upload_dir();
            $path = trailingslashit($upload_dir['basedir']) . 'apple-pay-certs/';
            if (!is_dir($path)) {
                wp_mkdir_p($path);
            }
            $key_file = $path . 'merchant.key';
            file_put_contents($key_file, $key_pem);

            $this->update_option('private_key', $key_file);
        }

        return parent::process_admin_options();
    }

    /**
     * Upload a PEM or KEY file and update option
     */
    protected function save_uploaded_pem($file, $option_name)
    {
        $overrides = [
            'test_form' => false,
            'mimes' => [
                'pem' => ['application/x-x509-ca-cert', 'application/pkix-cert', 'text/plain'],
                'key' => ['application/octet-stream', 'application/x-pem-file', 'text/plain'],
            ],
        ];

        $move = wp_handle_upload($file, $overrides);

        if (isset($move['error'])) {
            WC_Admin_Settings::add_error(sprintf(
                __('Upload error for %s: %s', 'custom-card-payment'),
                $option_name,
                esc_html($move['error'])
            ));
        } else {
            $this->update_option($option_name, $move['file']);
        }
    }

    public function enqueue_apple_pay_data()
    {
        if (is_checkout()) {
            $cart_total = WC()->cart ? WC()->cart->get_total('edit') : 0;

            wp_localize_script('apple-pay-blocks', 'apple_pay_gateway_data', [
                'title' => $this->get_option('title'),
                'description' => $this->get_option('description'),
                'merchantIdentifier' => $this->get_option('merchant_identifier'),
                'supportedNetworks' => $this->get_option('supported_networks', ['visa', 'masterCard', 'amex']),
                'countryCode' => substr(get_option('woocommerce_default_country'), 0, 2),
                'currency' => get_woocommerce_currency(),
                'storeName' => get_bloginfo('name'),
                'cartTotal' => (float) $cart_total,
                'validationEndpoint' => rest_url('montypay/v1/validate'),
                'processPaymentEndpoint' => rest_url('montypay/v1/apple_pay_process'),
            ]);
        }
    }

    public function handle_rest_validation()
    {
        $raw = file_get_contents('php://input');
        $data = json_decode($raw, true);

        $logger = new WC_Logger();
        $logger->info('Apple Pay Validation Data', ['data' => $data]);

        // Validate session
        $session = $this->payment_processor->handle_validation($data['validationURL']);

        if (is_wp_error($session)) {
            return new WP_REST_Response([
                'error' => $session->get_error_message()
            ], 400);
        }

        return new WP_REST_Response($session);
    }

    /**
     * REST callback for Apple Pay.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function handle_apple_pay(WP_REST_Request $request)
    {
        $logger = new WC_Logger();
        $data = $request->get_json_params();
        $logger->info('ApplePay request', $data);

        if (empty($data['items']) || empty($data['paymentData'])) {
            return new WP_REST_Response(
                ['status' => 'failure', 'message' => 'Missing items or paymentData'],
                400
            );
        }

        // 1) create a new order
        $order = wc_create_order([
            'status' => 'pending',
            'customer_id' => get_current_user_id(),
        ]);
        if (is_wp_error($order)) {
            return new WP_REST_Response(
                ['status' => 'failure', 'message' => $order->get_error_message()],
                500
            );
        }

        // Save customer IP address
        $customer_ip = $_SERVER['REMOTE_ADDR'] ?? $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['HTTP_CLIENT_IP'] ?? 'Unknown';
        $order->update_meta_data('_customer_ip_address', $customer_ip);
        
        // Set the payment method for this order
        $order->set_payment_method($this->id);
        $order->set_payment_method_title('Apple Pay');

        // 2) add each item
        foreach ($data['items'] as $item) {
            $product = wc_get_product(absint($item['product_id']));
            if ($product && $item['quantity'] > 0) {
                $order->add_product($product, intval($item['quantity']));
            }
        }

        // 4) Set billing & shipping addresses
        if (!empty($data['billingContact'])) {
            $bc = $data['billingContact'];
            $order->set_address([
                'first_name' => sanitize_text_field($bc['first_name'] ?? ''),
                'last_name' => sanitize_text_field($bc['last_name'] ?? ''),
                'company' => sanitize_text_field($bc['company'] ?? ''),
                'email' => sanitize_email($bc['email'] ?? ''),
                'phone' => sanitize_text_field($bc['phone'] ?? ''),
                'address_1' => sanitize_text_field($bc['address_1'] ?? ''),
                'address_2' => sanitize_text_field($bc['address_2'] ?? ''),
                'city' => sanitize_text_field($bc['city'] ?? ''),
                'state' => sanitize_text_field($bc['state'] ?? ''),
                'postcode' => sanitize_text_field($bc['postcode'] ?? ''),
                'country' => sanitize_text_field($bc['country'] ?? ''),
            ], 'billing');
        }

        if (!empty($data['shippingContact'])) {
            $sc = $data['shippingContact'];
            $order->set_address([
                'first_name' => sanitize_text_field($sc['first_name'] ?? ''),
                'last_name' => sanitize_text_field($sc['last_name'] ?? ''),
                'company' => sanitize_text_field($sc['company'] ?? ''),
                'address_1' => sanitize_text_field($sc['address_1'] ?? ''),
                'address_2' => sanitize_text_field($sc['address_2'] ?? ''),
                'city' => sanitize_text_field($sc['city'] ?? ''),
                'state' => sanitize_text_field($sc['state'] ?? ''),
                'postcode' => sanitize_text_field($sc['postcode'] ?? ''),
                'country' => sanitize_text_field($sc['country'] ?? ''),
            ], 'shipping');
        }

        // then totals, save, process payment, return response…
        $order->calculate_totals();
        $order->save();

        // 5) call your MontyPay processor
        $result = $this->payment_processor->process_payment(
            $order->get_id(),
            $data['paymentData']
        );
        (new WC_Logger())->info('ApplePay →', $result);

        // 6) return JSON
        if (!empty($result['result']) && $result['result'] === 'success') {
            return new WP_REST_Response(
                ['status' => 'success', 'redirect_url' => $result['redirect_url']],
                200
            );
        }

        return new WP_REST_Response(
            ['status' => 'failure', 'message' => $result['error'] ?? 'Payment error'],
            402
        );
    }

    public function enqueue_applepay_classic_assets()
    {
        if (!is_checkout() || is_wc_endpoint_url()) {
            return;
        }

        // 1) Enqueue Eruda (optional) for mobile debugging
        wp_enqueue_script(
            'eruda',
            'https://cdn.jsdelivr.net/npm/eruda',
            [],
            null,
            true
        );
        wp_add_inline_script('eruda', 'eruda.init();', 'after');

        // 2) Enqueue your custom ApplePay JS
        wp_enqueue_script(
            'montypay-applepay-classic',
            plugin_dir_url(__FILE__) . '../../assets/js/apple-pay-classic.js',
            ['jquery'], // or [] if you prefer vanilla
            '1.0.0',
            true
        );

        // 3) Make your PHP settings available in JS
        wp_localize_script(
            'montypay-applepay-classic',
            'MontyPayClassic',
            [
                'validationEndpoint' => rest_url('montypay/v1/validate'),
                'processPaymentEndpoint' => rest_url('montypay/v1/apple_pay_process'),
                'nonce' => wp_create_nonce('wc-apple-pay'),
                'merchantIdentifier' => $this->get_option('merchant_identifier'),
                'supportedNetworks' => $this->get_option('supported_networks'),
                'countryCode' => substr(get_option('woocommerce_default_country'), 0, 2),
                'currencyCode' => get_woocommerce_currency(),
                'storeName' => get_bloginfo('name'),
            ]
        );
    }

    public function payment_fields()
    {
        // 1) Wrap in a container and give the button a known ID
        ?>
        <div style="display: flex; flex-direction: column; justify-content: center;" id="apple-pay-button-container">
            <div id="apple-pay-form-notice" style="
                background: #fff3cd;
                border: 1px solid #ffeaa7;
                border-radius: 4px;
                padding: 12px;
                margin-bottom: 15px;
                font-size: 14px;
                color: #856404;
                text-align: center;
            ">
                <strong>📋 Please complete the billing form above before using Apple Pay</strong>
            </div>
            <div class="MontyPayLogo">
                <label><?php _e('Powered By', 'custom-card-payment'); ?></label>
                <img src="https://montypaydev.com/global_assets/images/MontyPayLogo.png"
                    alt="<?php esc_attr_e('MontyPay Logo', 'custom-card-payment'); ?>"
                    class="MontyPayLogo MontyPayLogo-classic" />
            </div>
        </div>
        <script>
            ; (function () {
                const settings = window.MontyPayClassic;

                // 2) Add form validation before processing Apple Pay:
                const handleApplePay = () => {
                    // First validate required billing fields
                    const requiredFields = [
                        { id: '#billing_first_name', name: 'First Name' },
                        { id: '#billing_last_name', name: 'Last Name' },
                        { id: '#billing_email', name: 'Email' },
                        { id: '#billing_phone', name: 'Phone' },
                        { id: '#billing_address_1', name: 'Address' },
                        { id: '#billing_city', name: 'City' },
                        { id: '#billing_postcode', name: 'Postcode' },
                        { id: '#billing_country', name: 'Country' }
                    ];

                    const missingFields = [];
                    
                    for (const field of requiredFields) {
                        const value = jQuery(field.id).val();
                        if (!value || value.trim() === '') {
                            missingFields.push(field.name);
                        }
                    }

                    if (missingFields.length > 0) {
                        alert('Please complete the following required fields before using Apple Pay:\n\n' + missingFields.join('\n'));
                        // Scroll to first missing field
                        const firstMissingField = jQuery('#billing_' + missingFields[0].toLowerCase().replace(' ', '_'));
                        if (firstMissingField.length) {
                            jQuery('html, body').animate({
                                scrollTop: firstMissingField.offset().top - 100
                            }, 500);
                            firstMissingField.focus();
                        }
                        return;
                    }

                    // Validate email format
                    const email = jQuery('#billing_email').val();
                    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    if (!emailRegex.test(email)) {
                        alert('Please enter a valid email address.');
                        jQuery('#billing_email').focus();
                        return;
                    }

                    const priceText = jQuery('.order-total .amount').first().text() || '';
                    const amount = parseFloat(priceText.replace(/[^0-9.]/g, ''));
                    if (isNaN(amount) || amount <= 0) {
                        alert('Cannot process payment: invalid total');
                        return;
                    }
                    function getWooCheckoutAddress(type) {
                        // type is 'billing' or 'shipping'
                        const prefix = `${type}_`;
                        return {
                            first_name: jQuery(`#${prefix}first_name`).val() || '',
                            last_name: jQuery(`#${prefix}last_name`).val() || '',
                            company: jQuery(`#${prefix}company`).val() || '',
                            country: jQuery(`#${prefix}country`).val() || '',
                            address_1: jQuery(`#${prefix}address_1`).val() || '',
                            address_2: jQuery(`#${prefix}address_2`).val() || '',
                            city: jQuery(`#${prefix}city`).val() || '',
                            state: jQuery(`#${prefix}state`).val() || '',
                            postcode: jQuery(`#${prefix}postcode`).val() || '',
                            // phone & email only exist on billing by default
                            phone: type === 'billing' ? jQuery('#billing_phone').val() || '' : '',
                            email: type === 'billing' ? jQuery('#billing_email').val() || '' : ''
                        };
                    }

                    // Get cart items from WooCommerce cart object
                    const items = [];
                    console.log('Starting to extract items...');
                    
                    // First get the cart data from WooCommerce
                    jQuery.ajax({
                        url: wc_checkout_params.ajax_url,
                        type: 'POST',
                        data: {
                            action: 'get_cart_items'
                        },
                        success: function(response) {
                            console.log('AJAX Response:', response);
                            
                            if (response && response.success && response.data && response.data.items) {
                                const cartItems = response.data.items;
                                console.log('Cart items from server:', cartItems);
                                
                                // Now process each cart item
                                jQuery('.woocommerce-checkout-review-order-table tbody tr.cart_item').each(function() {
                                    const $row = jQuery(this);
                                    const $productName = $row.find('.product-name');
                                    
                                    // Get product name
                                    const productName = $productName.clone().find('strong').remove().end().text().trim();
                                    console.log('Processing product:', productName);
                                    
                                    // Find matching item in cart data
                                    const cartItem = cartItems.find(item => 
                                        item.name.trim() === productName || 
                                        productName.includes(item.name.trim())
                                    );
                                    
                                    if (cartItem) {
                                        // Extract quantity
                                        const quantityText = $productName.find('.product-quantity').text();
                                        const quantity = parseInt(quantityText.replace(/[^0-9]/g, ''));
                                        
                                        items.push({
                                            product_id: cartItem.product_id,
                                            variation_id: cartItem.variation_id || 0,
                                            quantity: quantity
                                        });
                                        console.log('Added item:', { 
                                            product_id: cartItem.product_id, 
                                            quantity: quantity 
                                        });
                                    } else {
                                        console.log('No matching cart item found for:', productName);
                                    }
                                });
                                
                                console.log('Final items array:', items);
                            } else {
                                console.error('Invalid response format:', response);
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error('AJAX Error:', error);
                        }
                    });
                    
                    const session = new ApplePaySession(3, {
                        countryCode: settings.countryCode,
                        currencyCode: settings.currencyCode,
                        merchantCapabilities: ['supports3DS'],
                        supportedNetworks: settings.supportedNetworks,
                        total: { label: settings.storeName, amount: amount.toFixed(2) },
                        merchantIdentifier: settings.merchantIdentifier,
                    });

                    session.onvalidatemerchant = async (event) => {
                        const res = await fetch(settings.validationEndpoint, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            credentials: 'include',
                            body: JSON.stringify({
                                validationURL: event.validationURL,
                                security: settings.nonce
                            }),
                        });
                        if (!res.ok) throw new Error(`Validation failed: ${res.status}`);
                        const body = await res.json();
                        session.completeMerchantValidation(body);
                    };

                    session.onpaymentauthorized = async (event) => {
                        const billingAddress = getWooCheckoutAddress('billing');
                        const shippingAddress = getWooCheckoutAddress('shipping');
                        const res = await fetch(settings.processPaymentEndpoint, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                                paymentData: event.payment.token.paymentData,
                                billingContact: billingAddress,
                                shippingContact: shippingAddress,
                                items
                            })
                        });
                        const data = await res.json();
                        console.log(data);
                        if (data.status == 'success') {
                            session.completePayment(ApplePaySession.STATUS_SUCCESS);
                            window.location = data.redirect_url;
                        } else {
                            session.completePayment(ApplePaySession.STATUS_FAILURE);
                            alert(data.message || 'Payment failed');
                        }
                    };

                    session.begin();
                };

                // only one init, and it's async
                async function initApplePayButton() {
                    const container = document.getElementById('apple-pay-button-container');
                    
                    // Clear any existing Apple Pay button but preserve the notice and logo
                    const existingButton = container.querySelector('#apple-pay-button-classic');
                    if (existingButton) {
                        existingButton.remove();
                    }

               

                    // Check if Apple Pay is available
                    if (!window.ApplePaySession) {
                        const msg = document.createElement('p');
                        msg.textContent = 'Apple Pay is not supported in this browser.';
                        msg.style.cssText = `
                            color: #666;
                            font-size: 0.9em;
                            text-align: center;
                            margin: 20px 0;
                        `;
                        container.appendChild(msg);
                        return;
                    }

                    // Check if device can make payments
                    try {
                        const canMakePayments = await ApplePaySession.canMakePayments();
                        if (!canMakePayments) {
                            const msg = document.createElement('p');
                            msg.textContent = 'Please set up Apple Pay in your device settings to use this payment method.';
                            msg.style.cssText = `
                                color: #666;
                                font-size: 0.9em;
                                text-align: center;
                                margin: 20px 0;
                            `;
                            container.appendChild(msg);
                            return;
                        }

                        // Check if device can make payments with active card
                        const canMakePaymentsWithActiveCard = await ApplePaySession.canMakePaymentsWithActiveCard(settings.merchantIdentifier);
                        if (!canMakePaymentsWithActiveCard) {
                            const msg = document.createElement('p');
                            msg.textContent = 'Please add a card to your Apple Wallet to use Apple Pay.';
                            msg.style.cssText = `
                                color: #666;
                                font-size: 0.9em;
                                text-align: center;
                                margin: 20px 0;
                            `;
                            container.appendChild(msg);
                            return;
                        }

                        // If we get here, device is iOS and can make payments
                        const btn = document.createElement('button');
                        btn.id = 'apple-pay-button-classic';
                        btn.type = 'button';
                        btn.disabled = true;
                        btn.style.cssText = `
                            appearance: -apple-pay-button;
                            -apple-pay-button-type: buy;
                            -apple-pay-button-style: black;
                            width: 100%;
                            max-width: 320px;
                            height: 44px;
                            border: none;
                            margin: 10px auto;
                            display: block;
                            cursor: not-allowed;
                            opacity: 0.5;
                            filter: grayscale(100%);
                            pointer-events: none;
                        `;
                        btn.addEventListener('click', (e) => {
                            if (btn.disabled) {
                                e.preventDefault();
                                alert('Please complete the billing form above before using Apple Pay.');
                                return;
                            }
                            handleApplePay();
                        });
                        container.appendChild(btn);

                    } catch (error) {
                        console.error('Apple Pay check failed:', error);
                        const msg = document.createElement('p');
                        msg.textContent = 'Unable to verify Apple Pay availability. Please use another payment method.';
                        msg.style.cssText = `
                            color: #d32f2f;
                            font-size: 0.9em;
                            text-align: center;
                            margin: 20px 0;
                            padding: 10px;
                            background: #ffebee;
                            border: 1px solid #f8bbd9;
                            border-radius: 4px;
                        `;
                        container.appendChild(msg);
                    }
                }

                // Monitor form fields and update Apple Pay availability
                const checkFormCompletion = () => {
                    const requiredFields = [
                        '#billing_first_name', '#billing_last_name', '#billing_email', 
                        '#billing_phone', '#billing_address_1', '#billing_city', 
                        '#billing_postcode', '#billing_country'
                    ];

                    const allFieldsFilled = requiredFields.every(field => {
                        const value = jQuery(field).val();
                        return value && value.trim() !== '';
                    });

                    const notice = jQuery('#apple-pay-form-notice');
                    const applePayButton = jQuery('#apple-pay-button-classic');

                    if (allFieldsFilled) {
                        notice.hide();
                        applePayButton.prop('disabled', false);
                        applePayButton.css({
                            'opacity': '1',
                            'cursor': 'pointer',
                            'filter': 'none',
                            'pointer-events': 'auto'
                        });
                    } else {
                        notice.show();
                        applePayButton.prop('disabled', true);
                        applePayButton.css({
                            'opacity': '0.5',
                            'cursor': 'not-allowed',
                            'filter': 'grayscale(100%)',
                            'pointer-events': 'none'
                        });
                    }
                };

                // Monitor form fields for changes
                jQuery(document).on('change input blur', 'input[id^="billing_"], select[id^="billing_"]', checkFormCompletion);

                // Initial check
                checkFormCompletion();

                // Initialize immediately
                initApplePayButton();
            })();
        </script>
        <?php
    }

    /**
     * AJAX handler for getting cart items
     */
    public function get_cart_items() {
        $items = array();
        
        if (WC()->cart) {
            foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
                $product = $cart_item['data'];
                $items[] = array(
                    'product_id' => $product->get_id(),
                    'variation_id' => $cart_item['variation_id'],
                    'name' => $product->get_name(),
                    'quantity' => $cart_item['quantity']
                );
            }
        }
        
        wp_send_json_success(array('items' => $items));
    }

    /**
     * Modify the payment method title display
     *
     * @param string $title The payment method title
     * @param WC_Order $order The order object
     * @return string Modified payment method title
     */
    public function modify_payment_method_title($title, $order) {
        // Check if this is our Apple Pay gateway
        if ($order->get_payment_method() === $this->id || $order->get_payment_method() === 'apple_pay_gateway') {
            return 'Apple Pay';
        }
        return $title;
    }





   
    /**
     * Show payment method in order list
     */
    public function show_payment_method_in_order_list($column, $post_id) {
        if ($column === 'order_status') {
            $order = wc_get_order($post_id);
            if ($order && $order->get_payment_method() === 'apple_pay_gateway') {
                echo '<br><small style="color: #007cba; font-weight: bold;">🍎 Apple Pay</small>';
            }
        }
    }
}

add_action('woocommerce_init', function () {
    if (!isset($GLOBALS['wc_gateway_custom_applepay'])) {
        $GLOBALS['wc_gateway_custom_applepay'] = new WC_Gateway_Custom_ApplePay();
    }
});
add_filter('woocommerce_payment_gateways', function ($methods) {
    $methods[] = 'WC_Gateway_Custom_ApplePay';
    return $methods;
});