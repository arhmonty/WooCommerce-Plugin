<?php
if (!defined('ABSPATH'))
    exit;

class Custom_Payment_Processor_ApplePay
{
    private $merchant_key;
    private $merchant_pass;
    private $merchant_identifier;
    private $private_key;
    private $certificate;
    private $api_url = 'https://api.montypay.com/post-va';
    private $logger;

    private $merchant_domain;

    public function __construct($merchant_key, $merchant_pass, $merchant_identifier, $private_key, $certificate, $merchant_domain)
    {
        $this->merchant_key = $merchant_key;
        $this->merchant_pass = $merchant_pass;
        $this->merchant_identifier = $merchant_identifier;
        $this->merchant_domain = $merchant_domain;
        $this->private_key = $this->url_to_path($private_key);
        $this->certificate = $this->url_to_path($certificate);
        $this->logger = new WC_Logger();
        
        // Add filter to modify payment method display
        add_filter('woocommerce_order_get_payment_method_title', array($this, 'modify_payment_method_title'), 10, 2);
    }

    /**
     * Modify the payment method title display
     *
     * @param string $title The payment method title
     * @param WC_Order $order The order object
     * @return string Modified payment method title
     */
    public function modify_payment_method_title($title, $order) {
        if ($order->get_payment_method() === 'applepay') {
            return 'Payment via Apple Pay';
        }
        return $title;
    }

    private function url_to_path($url)
    {
        $upload_dir = wp_upload_dir();
        $base_url = $upload_dir['baseurl'];
        $base_path = $upload_dir['basedir'];

        return str_replace($base_url, $base_path, $url);
    }
    public function handle_validation($validation_url)
    {
        try {
            $this->logger->info('VALIDATION STARTED', [
                'validation_url' => $validation_url,
                'merchant_key' => $this->merchant_key,
            ]);
            $this->logger->info('CERTIFICATE PATHS', [
                'cert' => $this->certificate,
                'key' => $this->private_key,
                'cert_exists' => file_exists($this->certificate),
                'key_exists' => file_exists($this->private_key)
            ]);
            if (!file_exists($this->certificate)) {
                throw new Exception("Certificate file not found: {$this->certificate}");
            }
            if (!file_exists($this->private_key)) {
                throw new Exception("Private key file not found: {$this->private_key}");
            }

            // Verify file permissions
            if (substr(sprintf('%o', fileperms($this->certificate)), -4) !== '0600') {
                chmod($this->certificate, 0600);
            }

            // Absolute paths to your .pem files (store them outside webroot!)
            $cert_path = $this->certificate; // e.g., WP_PLUGIN_DIR . '/your-plugin/certs/apple-pay-cert.pem';
            $key_path = $this->private_key; // e.g., WP_PLUGIN_DIR . '/your-plugin/certs/apple-pay-key.pem';

            $payload = json_encode([
                'merchantIdentifier' => $this->merchant_identifier,
                'displayName' => get_bloginfo('name'),
                'initiative' => 'web',
                'initiativeContext' => $this->merchant_domain,
            ]);

            $ch = curl_init($validation_url);
            curl_setopt($ch, CURLOPT_SSLCERTTYPE, 'PEM');
            curl_setopt($ch, CURLOPT_SSLKEYTYPE, 'PEM');
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'Accept: application/json',
            ]);
            // **Mutual TLS certs**:
            curl_setopt($ch, CURLOPT_SSLCERT, $cert_path);
            curl_setopt($ch, CURLOPT_SSLKEY, $key_path);

            $this->logger->info('VALIDATION REQUEST', [
                'validation_url' => $validation_url,
                'payload' => $payload,
            ]);
            $response = curl_exec($ch);
            if (curl_errno($ch)) {
                throw new Exception('cURL error: ' . curl_error($ch));
            }
            curl_close($ch);

            $body = json_decode($response, true);
            $this->logger->info('VALIDATION RESPONSE', ['response' => $body,]);
            return $body;

        } catch (Exception $e) {
            $this->logger->error('VALIDATION ERROR', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
            return new WP_Error('validation_error', $e->getMessage());
        }
    }


    /**
     * Process an Apple Pay payment via MontyPay.
     *
     * @param int   $order_id
     * @param mixed $payment_data  The event.payment.token.paymentData object
     * @return array{
     *   result:    string,          // 'success' or 'failure'
     *   redirect_url?: string,      // on success
     *   error?:    string           // on failure
     * }
     */
    public function process_payment($order_id, $payment_data)
    {
        // 1) Load the order
        $order = wc_get_order($order_id);
        if (!$order) {
            return [
                'result' => 'failure',
                'error' => 'Invalid order ID',
            ];
        }
        $this->logger->info('order', [
            $order
        ]);


        $token_payload = [
            'paymentData' => [
                'data' => $payment_data['data'],
                'signature' => $payment_data['signature'],
                'header' => $payment_data['header'],
                'version' => $payment_data['version'],
            ],
        ];

        // 2) Build the MontyPay payload with payer information
        $params = [
            'action' => 'SALE',
            'client_key' => $this->merchant_key,
            'brand' => 'applepay',
            'order_id' => 'ORDER' . $order->get_id(),
            'order_amount' => number_format((float) $order->get_total(), 2, '.', ''),
            'order_currency' => $order->get_currency(),
            'order_description' => sprintf('Order #%d', $order->get_id()),
            'payer_ip' => $_SERVER['REMOTE_ADDR'] ?? $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['HTTP_CLIENT_IP'] ?? '',
            'return_url' => $order->get_checkout_order_received_url(),
            'identifier' => $this->merchant_identifier,
            
            // Payer information fields
            'payer_first_name' => sanitize_text_field($order->get_billing_first_name()),
            'payer_last_name' => sanitize_text_field($order->get_billing_last_name()),
            'payer_email' => sanitize_email($order->get_billing_email()),
            'payer_phone' => sanitize_text_field($order->get_billing_phone()),
            'payer_address' => sanitize_text_field($order->get_billing_address_1() . ' ' . $order->get_billing_address_2()),
            'payer_country' => sanitize_text_field($order->get_billing_country()),
            'payer_state' => sanitize_text_field($order->get_billing_state()),
            'payer_city' => sanitize_text_field($order->get_billing_city()),
            'payer_zip' => sanitize_text_field($order->get_billing_postcode()),
            
            // MontyPay wants the whole token JSON under parameters[paymentToken]
            'parameters[paymentToken]' => wp_json_encode($token_payload),
        ];


        $raw = $params['identifier']
            . $params['order_id']
            . $params['order_amount']
            . $params['order_currency']
            . $this->merchant_pass;

        // Reverse the string and uppercase
        $reversed_upper = strtoupper(strrev($raw));

        // 3) MD5-hash it
        $session_hash = md5($reversed_upper);
        $params['hash'] = $session_hash;

        $this->logger->info('PAYMENT REQUEST WITH PAYER INFO', [
            'params' => $params,
            'payer_details' => [
                'first_name' => $params['payer_first_name'],
                'last_name' => $params['payer_last_name'],
                'email' => $params['payer_email'],
                'phone' => $params['payer_phone'],
                'address' => $params['payer_address'],
                'city' => $params['payer_city'],
                'state' => $params['payer_state'],
                'country' => $params['payer_country'],
                'zip' => $params['payer_zip'],
                'ip' => $params['payer_ip']
            ]
        ]);

        // 4) Call MontyPay
        $response = wp_remote_post($this->api_url, [
            'timeout' => 60,
            'sslverify' => true,
            'body' => $params,
        ]);

        $this->logger->info('PAYMENT RESPONSE', [
            'response' => $response,
        ]);



        $raw = wp_remote_retrieve_body($response);
        $data = json_decode($raw, true);

        // 5) Interpret MontyPay's response
        if (
            isset($data['status'], $data['result'])
            && $data['status'] === 'SETTLED'
            && $data['result'] === 'SUCCESS'
        ) {
            // Save customer IP address to order meta
            $customer_ip = $_SERVER['REMOTE_ADDR'] ?? $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['HTTP_CLIENT_IP'] ?? 'Unknown';
            $order->update_meta_data('_customer_ip_address', $customer_ip);
            
            // Add order note for Apple Pay payment with payer details
            $order->add_order_note(sprintf(
                __('Payment completed via Apple Pay. Transaction ID: %s. Customer: %s %s (%s). IP: %s', 'custom-card-payment'),
                $data['transaction_id'] ?? 'N/A',
                $order->get_billing_first_name(),
                $order->get_billing_last_name(),
                $order->get_billing_email(),
                $customer_ip
            ));
            
            $order->save_meta_data();
            
            // Tell WooCommerce this is done
            $order->payment_complete();
            $order->update_status('processing');
            return [
                'result' => 'success',
                'redirect_url' => $params['return_url'],
            ];
        }
        if (
            isset($data['status'], $data['result'])
            && $data['status'] === 'DECLINED'
            && $data['result'] === 'DECLINED'
        ) {
            $order->update_status('failed');
            return [
                'result' => 'payment declined by the gateway',
                'error' => $data['error'] ?? $data['message'] ?? 'Payment not accepted ',
            ];
        }

        // 6) On failure, bubble up MontyPay's error message
        return [
            'result' => 'failure',
            'error' => $data['error'] ?? $data['message'] ?? 'Payment error',
        ];
    }

}