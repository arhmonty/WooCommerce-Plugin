<?php
use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

if (!class_exists('Custom_Card_Applepay_Blocks_Integration')) {
    class Custom_Card_Applepay_Blocks_Integration extends AbstractPaymentMethodType
    {
        protected $name = 'apple_pay_gateway';
        protected $settings;



        public function initialize()
        {
            $this->settings = get_option('woocommerce_apple_pay_gateway_settings', []);
        }

        public function is_active()
        {
            return isset($this->settings['enabled']) && wc_string_to_bool($this->settings['enabled']);
        }

        public function get_payment_method_script_handles()
        {
            wp_register_style(
                'apple-pay-blocks-style',
                plugins_url('../assets/css/applepay.css', dirname(__FILE__)), // use unique file or name
                [],
                '1.0.0'
            );

            // Enqueue shared utils first
            wp_register_script(
                'shared-utils',
                plugins_url('../assets/js/shared-utils.js', dirname(__FILE__)),
                ['wc-blocks-registry', 'wc-settings', 'wp-element', 'wp-html-entities'],
                '1.0.0',
                true
            );

            // Enqueue shared utils first
            wp_register_script(
                'apple-pay-blocks',
                plugins_url('../assets/js/apple-pay.js', dirname(__FILE__)),
                ['shared-utils'],
                '1.0.0',
                true
            );

            return ['apple-pay-blocks'];
        }

        public function get_payment_method_data()
        {
            // Get country code with proper validation
            $base_location = wc_get_base_location();
            $country_code = $base_location['country'] ?? 'US';
            $country_code = substr(strtoupper($country_code), 0, 2);
            $validation_endpoint = rest_url('montypay/v1/validate');
            $processPaymentEndpoint = rest_url('montypay/v1/apple_pay_process');

            return [
                'title' => $this->settings['title'] ?? __('Apple Pay', 'custom-card-payment'),
                'description' => $this->get_dynamic_description(),
                'supports' => ['products'],
                'cssClass' => 'custom-card-gateway',
                'icon' => $this->get_payment_icon(),
                'countryCode' => $country_code, // Add country code to data
                'currency' => get_woocommerce_currency(),
                'storeName' => get_bloginfo('name'),
                'merchantIdentifier' => $this->settings['merchant_identifier'] ?? '',
                'supportedNetworks' => $this->settings['supported_networks'] ?? ['visa', 'masterCard', 'amex'],
                'validationEndpoint' => $validation_endpoint,
                'validationUrl' => $this->settings['validation_url'] ?? 'https://apple-pay-gateway.apple.com/paymentservices/startSession/paymentSession',
                'processPaymentEndpoint' => $processPaymentEndpoint,
                'merchantmission' => $this->settings['merchant_mission'] ?? '',
            ];
        }

        private function get_dynamic_description()
        {
            // This will be overridden by JavaScript logic
            return $this->settings['description'] ?? '';
        }

        private function get_payment_icon()
        {
            return esc_url(plugins_url('../assets/images/apple-pay-logo.png', dirname(__FILE__)));
        }
    }
}