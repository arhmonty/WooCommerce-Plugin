<?php

require_once plugin_dir_path(__FILE__) . '../../abstract/class-wc-abstract-custom-gateway.php';

class WC_Gateway_Custom_Card extends WC_Abstract_Custom_Gateway {
    /**
 * @var Custom_Payment_Processor
 */
protected $payment_processor;
    public function __construct() {
        $this->id                = 'custom_card_gateway';
        $this->method_title      = __('MontyPay - S2S', 'custom-card-payment');
        $this->method_description= __('Collects card details directly in checkout page', 'custom-card-payment');
        parent::__construct();
        $this->has_fields        = true; // we’re adding our own form fields
       

        // instantiate your processor
        $this->payment_processor = new Custom_Payment_Processor(
            $this->get_option('merchant_key'),
            $this->get_option('merchant_pass')
        );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_checkout_styles' ) );

    }
  

    public function enqueue_checkout_styles() {
        if ( is_checkout() && ! is_wc_endpoint_url() ) {
            wp_enqueue_style(
                'montypay-block-styles',
                plugin_dir_url( __FILE__ ) . '../../assets/css/block.css',
                array(),
                '1.0'
            );
        }
    }
    
// ----------------------------------------------------------------CLASSIC CHECKOUT------------------------------------------------------------------------------------

    /**
     * Output credit card form fields on classic checkout
     */
    public function payment_fields() {
        // URLs for the card and CVV icons
        $card_icons = [
            'visa'       => 'https://montypaydev.com/global_assets/images/visa.256x164.png',
            'mastercard' => 'https://montypaydev.com/global_assets/images/mastercard.256x161.png',
            'union'      => 'https://montypaydev.com/global_assets/images/unionpay.256x163.png',
        ];
        $cvv_icon_url     = 'https://montypaydev.com/global_assets/images/cvv.png';
        $defaultCardTypes = ['visa', 'mastercard'];
    ?>
    
        <!-- Responsive CSS to toggle icon containers -->
        <style>
        @media (max-width:768px) {
            .desktop-only { display: none !important; }
            .mobile-only  { display: block !important; }
        }
        @media (min-width:769px) {
            .desktop-only { display: flex !important;  margin-top: 3px !important; }
            .mobile-only  { display: none !important; }
        }
        .card-icon { width: 40px; margin-left: 8px; }
        </style>
    
        <!-- Payment Fields Markup -->
        <div class="custom-card-content">
            <div class="custom-card-fields classic-card-fields">
                <!-- Top Row: Card Number and icons -->
                <div class="card-number-row">
                    <label for="cc_number_display"><?php _e('Card Number','custom-card-payment'); ?></label>
                    <input
  id="cc_number_display"
  type="text"
  class="card-number-input"
  autocomplete="cc-number"
  placeholder="1234 1234 1234 1234"
  maxlength="19"
  oninput="handleCardNumberInput(this);"
/>
<input
  id="cc_number"
  name="cc_number"           
  type="hidden"
/>


    
                    <!-- Desktop: include all icons, show defaults only -->
                    <div class="card-icon-container desktop-only">
                        <?php foreach ($card_icons as $type => $url): ?>
                        <img
                            id="card_icon_<?php echo esc_attr($type); ?>"
                            src="<?php echo esc_url($url); ?>"
                            alt="<?php echo esc_attr(ucfirst($type)); ?>"
                            class="card-icon <?php echo esc_attr($type); ?>"
                            style="display: <?php echo in_array($type, $defaultCardTypes) ? 'inline-block' : 'none'; ?>;"
                        />
                        <?php endforeach; ?>
                    </div>
    
                    <!-- Mobile: single cycling icon -->
                    <div class="card-icon-container mobile-only">
                        <img
                            id="card_icon_cycle"
                            src="<?php echo esc_url($card_icons[$defaultCardTypes[0]]); ?>"
                            alt="Card Icon"
                            class="card-icon cycling"
                        />
                    </div>
                </div>
    
                <!-- Bottom Row: Expiry & CVV -->
                <div class="custom-card-bottom-row">
                    <!-- Expiry -->
                    <div class="form-row bottom-row-field">
                        <label for="cc_expiry"><?php _e('Expiration Date','custom-card-payment'); ?></label>
                        <input
                            id="cc_expiry"
                            name="cc_expiry"
                            type="text"
                            class="expiry-input"
                            autocomplete="cc-exp"
                            placeholder="MM / YY"
                            maxlength="7"
                            oninput="handleExpiryChange(this);"
                        />
                        <div class="payment-error expiry-error" id="expiry_error"></div>
                    </div>
                    <!-- CVV -->
                    <div class="cvv-container form-row bottom-row-field">
                        <label for="cc_cvv"><?php _e('Security Code','custom-card-payment'); ?></label>
                        <input
                            id="cc_cvv"
                            name="cc_cvv"
                            type="text"
                            class="cvv-input"
                            autocomplete="cc-csc"
                            placeholder="123"
                            maxlength="4"
                            oninput="this.value = this.value.replace(/\D/g, '');"
                        />
                        <img
                            src="<?php echo esc_url($cvv_icon_url); ?>"
                            alt="<?php esc_attr_e('CVV','custom-card-payment'); ?>"
                            class="cvv-icon cvv-icon-in-classic"
                        />
                    </div>
                </div>
    
                <!-- MontyPay Logo -->
                <div class="MontyPayLogo">
                    <label><?php _e('Powered By','custom-card-payment'); ?></label>
                    <img
                        src="https://montypaydev.com/global_assets/images/MontyPayLogo.png"
                        alt="<?php esc_attr_e('MontyPay Logo','custom-card-payment'); ?>"
                        class="MontyPayLogo MontyPayLogo-classic"
                    />
                </div>
            </div>
        </div>
    
        <!-- JavaScript for icon cycling & detection -->
        <script type="text/javascript" defer>
        cardIcons2 = <?php echo wp_json_encode($card_icons); ?>;
    
        function detectCardType(number) {
            const digits = number.replace(/\s/g, '');
            if (/^4/.test(digits)) return 'visa';
            if (/^(5[1-5]|222[1-9]|22[3-9]\d|2[3-6]\d{2}|27[01]\d|2720)/.test(digits)) return 'mastercard';
            if (/^62/.test(digits)) return 'union';
            return '';
        }
    
        function real_value_cc_number(input) {
            const raw = input.value.replace(/\D/g, '');
            const type = detectCardType(raw);
            return type ? raw : '';
        }
    
        function formatCardNumber(value) {
        const v = value.replace(/\s+/g, '').replace(/\D/g, '');
        const parts = v.match(/\d{1,4}/g);
        return parts ? parts.join(' ') : '';
    }
        (function(){
            const defaultTypes = <?php echo wp_json_encode($defaultCardTypes); ?>;
            let cycleIdx = 0, cycleTimer = null;
    
            function startCycle() {
                if (!window.matchMedia('(max-width:768px)').matches) return;
                stopCycle();
                cycleTimer = setInterval(() => {
                    const type = defaultTypes[cycleIdx];
                    document.getElementById('card_icon_cycle').src = cardIcons2[type];
                    cycleIdx = (cycleIdx + 1) % defaultTypes.length;
                }, 3000);
            }
    
            function stopCycle() {
                if (cycleTimer) {
                    clearInterval(cycleTimer);
                    cycleTimer = null;
                }
            }
    
            window.handleCardNumberInput = function(input) {
                const raw = input.value.replace(/\D/g, '');
  input.value = formatCardNumber(raw);

  // ✏️ **NEW** — keep cc_number hidden in sync
  document.getElementById('cc_number').value = raw;

  const type = detectCardType(raw);
                const desktopImgs = document.querySelectorAll('.desktop-only .card-icon');
    
                if (type && cardIcons2[type]) {
                    stopCycle();
                    // Hide all and show detected
                    desktopImgs.forEach(img => { img.style.display = 'none'; });
                    const found = document.getElementById('card_icon_' + type);
                    if (found) found.style.display = 'inline-block';
                    document.getElementById('card_icon_cycle').src = cardIcons2[type];
                } else {
                    // Show defaults
                    desktopImgs.forEach(img => {
                        const t = img.id.replace('card_icon_','');
                        img.style.display = defaultTypes.includes(t) ? 'inline-block' : 'none';
                    });
                    startCycle();
                }
            };
    
            // Kick off animation immediately and on resize
            startCycle();
            window.addEventListener('resize', startCycle);
        })();
    
    
            function formatExpiryInput(raw) {
    let digits = raw.replace(/\D/g, '');
    if (digits.length === 0) return '';
    
    // Auto-correct first digit
    if (digits.length === 1 && parseInt(digits[0]) > 1) {
        digits = '0' + digits;
    }
    
    let month = digits.slice(0, 2);
    let remainder = digits.slice(2);
    
    // Auto-correct month
    if (month.length === 2) {
        const monthNum = parseInt(month, 10);
        if (monthNum > 12) {
            month = '0' + month[0];
            remainder = digits.slice(1);
        }
    }
    
    // Build formatted string
    let formatted = month;
    if (remainder.length > 0) {
        formatted += ' / ' + remainder.slice(0, 2);
    }
    
    return formatted;
}

            function validateExpiry(expiry) {
    const cleaned = expiry.replace(/\D/g, '');
    if (cleaned.length !== 4) return 'Your card’s expiration date is incomplete.';

    const month = parseInt(cleaned.slice(0, 2), 10);
    const year = parseInt(cleaned.slice(2), 10);
    const currentYear = new Date().getFullYear() % 100;
    const currentMonth = new Date().getMonth() + 1;

    if (month < 1 || month > 12) return 'Invalid month , ';
    if (year < currentYear ) {
        return 'Your card’s expiration year is in the past.';
    }
    if (year > currentYear + 50) return 'Your card’s expiration year is invalid.';
    
    return '';
}
    
            function handleExpiryChange(input) {
                const rawInput = input.value;
                const digits = rawInput.replace(/\D/g, '');
                
                // Format the expiry date
                input.value = formatExpiryInput(digits);
                
                // Store raw digits in a hidden input for form submission
                let hiddenInput = document.getElementById('cc_expiry_raw');
                if (!hiddenInput) {
                    hiddenInput = document.createElement('input');
                    hiddenInput.type = 'hidden';
                    hiddenInput.id = 'cc_expiry_raw';
                    hiddenInput.name = 'cc_expiry_raw';
                    input.parentNode.appendChild(hiddenInput);
                }
                hiddenInput.value = digits;
                
                // Real-time validation
                const errorDiv = document.getElementById('expiry_error');
                if (digits.length === 4) {
                    const error = validateExpiry(digits);
                    if (error) {
                        input.style.borderColor = '#d9534f';
                        input.style.color = 'red';
                        errorDiv.textContent = error;
                        errorDiv.style.display = 'block';
                    } else {
                        input.style.borderColor = '';
                        input.style.color = '';
                        errorDiv.textContent = '';
                        errorDiv.style.display = 'none';
                    }
                } else {
                    input.style.borderColor = '';
                    input.style.color = '';
                    errorDiv.textContent = '';
                    errorDiv.style.display = 'none';
                }
            }
      
          
 
        </script>
  
    
        <?php
    }
    

    /**
     * Validate those fields before submission
     */
    public function validate_fields() {
        if ( empty( $_POST['cc_number'] ) || empty( $_POST['cc_expiry'] ) || empty( $_POST['cc_cvv'] ) ) {
            wc_add_notice( __( 'Please fill in all credit card fields.', 'custom-card-payment' ), 'error' );
            return false;
        }
        return true;
    }

    /**
     * Process payment on classic checkout
     */
    public function process_payment( $order_id ) {
        $logger = new WC_Logger();
        $logger->info(  'Processing payment for order ID: ' . $order_id ,['source' => 's2s-payment'] );
        $logger->info(  'POST data: ' . print_r( $_POST, true ),['source' => 's2s-payment'] );
        $order = wc_get_order( $order_id );
      
        // Gather the POSTed values
        $card_number = sanitize_text_field( $_POST['cc_number'] );
        $expiry      = sanitize_text_field( $_POST['cc_expiry'] );
        $cvv         = sanitize_text_field( $_POST['cc_cvv'] );

        try {
            $api_response = $this->payment_processor->process_payment(
                $order, $card_number, $expiry, $cvv
            );
            $logger->info(  'api response data: ' . print_r( $api_response, true ),['source' => 's2s-payment'] );

            // 1. Handle ALL redirect types first
            if (!empty($api_response['result']) && $api_response['result'] === 'REDIRECT') {
                $redirect_url = $this->payment_processor->create_3ds_redirect_page($api_response);
                
                // Add order note about redirect
                $order->update_status('pending', sprintf(
                    'Payment requires redirect (%s)',
                    $api_response['status'] // Will show "3DS" or "REDIRECT"
                ));
                $logger->info(  'redirect data: ' . print_r( $redirect_url, true ),['source' => 's2s-payment'] );

                return [
                    'result'   => 'success',
                    'redirect' => $redirect_url
                ];
            }
            
            // 2. Then handle success cases
            if (!empty($api_response['result']) && $api_response['result'] === 'SUCCESS') {
                if ($api_response['status'] === 'SETTLED') {
                    $order->payment_complete($api_response['trans_id'] ?? '');
                    return [
                        'result'   => 'success',
                        'redirect' => $this->get_return_url($order)
                    ];
                }
                
             
            }
    
            // 3. Handle declines
            if (!empty($api_response['result']) && $api_response['result'] === 'DECLINED') {
                throw new Exception('Payment declined by gateway');
            }
    
            // 4. Fallback error
            throw new Exception($api_response['message'] ?? 'Payment failed');
        } catch ( Exception $e ) {
            wc_add_notice( $e->getMessage(), 'error' );
            return [
                'result' => 'fail'
            ];
        }
    }
}
