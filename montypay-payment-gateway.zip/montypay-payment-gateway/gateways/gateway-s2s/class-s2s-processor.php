<?php
if (!defined('ABSPATH')) exit;

class Custom_Payment_Processor {
    private $merchant_key;
    private $merchant_pass;
    private $api_url = 'https://api.montypay.com/post';

    public function __construct($merchant_key, $merchant_pass) {
        $this->merchant_key  = $merchant_key;
        $this->merchant_pass = $merchant_pass;
    
    }

    private function generate_hash($email, $card_number) {
        $masked = substr($card_number, 0, 6) . substr($card_number, -4);
        $input  = strtoupper(strrev($email) . $this->merchant_pass . strrev($masked));
        return md5($input);
    }

    public function process_payment($order, $card_number, $expiry_date, $cvv) {
        $logger = wc_get_logger();
        $logger->info('Starting payment processing', ['source' => 's2s-payment']);

        // Validate the expiry format (MM/YY).
        
        $expiry_parts  = explode('/', $expiry_date);
        $expiry_month  = trim($expiry_parts[0]);
        $expiry_year   = '20' . trim($expiry_parts[1]);

        // Prepare data payload.
        $payload = [
            'action'            => 'SALE',
            'client_key'        => $this->merchant_key,
            'order_id'          => $order->get_order_number(),
            'order_amount'      => $order->get_total() . '.00',
            'order_currency'    => $order->get_currency(),
            'order_description' => 'Order #' . $order->get_order_number(),
            'card_number'       => $card_number,
            'card_exp_month'    => $expiry_month,
            'card_exp_year'     => $expiry_year,
            'card_cvv2'         => $cvv,
            'payer_first_name'  => $order->get_billing_first_name(),
            'payer_last_name'   => $order->get_billing_last_name(),
            'payer_address'     => $order->get_billing_address_1(),
            'payer_country'     => $order->get_billing_country(),
            'payer_state'       => $order->get_billing_state(),
            'payer_city'        => $order->get_billing_city(),
            'payer_zip'         => $order->get_billing_postcode(),
            'payer_email'       => $order->get_billing_email(),
            'payer_phone'       => $order->get_billing_phone(),
            'payer_ip'          => $_SERVER['REMOTE_ADDR'],
            'term_url_3ds' => home_url('/payment-handler?order_id=' . $order->get_order_number(), 'https'),
            'recurring_init'    => 'Y',
            'hash'              => $this->generate_hash($order->get_billing_email(), $card_number)
        ];

        $body = http_build_query($payload);
        $args = [
            'headers' => ['Content-Type' => 'application/x-www-form-urlencoded'],
            'body'    => $body,
            'timeout' => 10
        ];

        $logger->info('API Request: ' . print_r($args, true), ['source' => 's2s-payment']);
        $response = wp_remote_post($this->api_url, $args);
        $logger->info('API Response: ' . print_r($response, true), ['source' => 's2s-payment']);

        if (is_wp_error($response)) {
            $logger->error('WP Error: ' . $response->get_error_message(),['source' => 's2s-payment']);
            throw new Exception('Gateway connection failed');
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        $logger->info('Parsed Response: ' . print_r($body, true),['source' => 's2s-payment']);

        // If a 3DS redirect is required, return the response.
        if (isset($body['result']) && $body['result'] === 'REDIRECT' && $body['status'] === '3DS') {
            return $body;
        }
        if (isset($body['result']) && $body['result'] === 'REDIRECT' && $body['status'] === 'REDIRECT') {
            return $body;
        }
        if (isset($body['result']) && $body['result'] === 'SUCCESS' && $body['status'] === 'SETTLED') {
            return $body;
        }
        if (isset($body['result']) && $body['result'] === 'DECLINED' && $body['status'] === 'DECLINED') {
            return $body;
        }
        if (isset($body['result']) && $body['result'] === 'SUCCESS' && $body['status'] === 'PENDING') {
            return $body ;
        }
       
        

      // Remove or modify the final error check to:
if ((empty($body['status']) || $body['status'] !== 'APPROVED') && $body['result'] !== 'REDIRECT') {
    $logger->error('Gateway Error: ' . ($body['message'] ?? 'Unknown error'),['source' => 's2s-payment']);
    throw new Exception($body['message'] ?? 'Payment failed');
}
        return $body;
    }

    public function create_3ds_redirect_page($response) {
        // Append the PaReq value (or at least its prefix) as a query parameter for later detection.
        $pa_req = isset($response['redirect_params']['PaReq']) ? $response['redirect_params']['PaReq'] : '';
        $term_url = add_query_arg('pa_req', rawurlencode($pa_req), home_url('/payment-handler?order_id=' . $response['order_id'], 'https'));
        
        $form = '<form id="3ds_redirect_form" action="' . esc_url($response['redirect_url']) . '" method="POST" style="display:none;">';
        foreach ($response['redirect_params'] as $key => $value) {
            $form .= '<input type="hidden" name="' . esc_attr($key) . '" value="' . esc_attr($value) . '">';
        }
        // Include the TermUrl with pa_req appended.
        $form .= '<input type="hidden" name="TermUrl" value="' . esc_attr($term_url) . '">';
        $form .= '</form>';
        $form .= '<script>
            document.getElementById("3ds_redirect_form").submit();
        </script>';
        
        // Save the form HTML in a transient for up to 15 minutes.
        $transient_key = '3ds_redirect_' . uniqid();
        set_transient($transient_key, $form, 15 * MINUTE_IN_SECONDS);
        
        // Return the URL pointing to your payment handler where the form transient is referenced.
        return home_url('/payment-handler?3ds_redirect=' . $transient_key);
    }


    
}



/**
 * Handle the WC Blocks checkout REST call + update the order status.
 */
add_action(
    'woocommerce_rest_checkout_process_payment_with_context',
    'custom_card_gateway_rest_process_payment',
    10,
    2
);

function custom_card_gateway_rest_process_payment( $context, $result ) {
    // Only run for our gateway
    if ( $context->payment_method !== 'custom_card_gateway' ) {
        return;
    }

    $order = $context->order;
    $logger = wc_get_logger();

    try {
        // 1) Collect card data from the REST context
        $payment_data = [
            'card_number' => $context->payment_data['card_number'] ?? '',
            'expiry_date' => $context->payment_data['expiry_date'] ?? '',
            'cvv'         => $context->payment_data['cvv']         ?? '',
        ];

        // 2) Load your gateway credentials
        $settings      = get_option( 'woocommerce_custom_card_gateway_settings', [] );
        $merchant_key  = $settings['merchant_key']  ?? '';
        $merchant_pass = $settings['merchant_pass'] ?? '';

        if ( ! $merchant_key || ! $merchant_pass ) {
            throw new Exception( 'Payment gateway not configured properly' );
        }

        // 3) Call your payment processor
        $processor    = new Custom_Payment_Processor( $merchant_key, $merchant_pass );
        $api_response = $processor->process_payment(
            $order,
            $payment_data['card_number'],
            $payment_data['expiry_date'],
            $payment_data['cvv']
        );

        // Log the raw API response
        $logger->info(
            'MontyPay API response: ' . wp_json_encode( $api_response ),
            ['source' => 's2s-payment']
        );

        // Normalize
        $result_code     = strtoupper( $api_response['result']          ?? '' );
        $status_code     = strtoupper( $api_response['status']          ?? '' );
        $redirect_method = strtoupper( $api_response['redirect_method'] ?? '' );

        // --- 3DS via GET Redirect ---
        if ( $result_code === 'REDIRECT'
             && $status_code   === '3DS'
             && $redirect_method === 'GET'
        ) {
            $redirect_url = $processor->create_3ds_redirect_page( $api_response );

            // 1a) Tell the Blocks UI to redirect
            $result->set_status( 'success' );
            $result->set_payment_details( [ 'redirect' => $redirect_url ] );
            $result->set_redirect_url( $redirect_url );

            // 1b) Put order on-hold until IPN confirms
            $order->update_status( 'pending', '3DS authentication required' );

            return;
        }

        // --- 3DS via POST Redirect ---
        if ( $result_code === 'REDIRECT'
             && $status_code   === '3DS'
             && $redirect_method === 'POST'
        ) {
            $redirect_url = $processor->create_3ds_redirect_page( $api_response );

            $result->set_status( 'success' );
            $result->set_payment_details( [ 'redirect' => $redirect_url ] );
            $result->set_redirect_url( $redirect_url );

            $order->update_status( 'pending', '3DS authentication required' );
            return;
        }

        // --- Generic Redirect (e.g. non-3DS) ---
        if ( $result_code === 'REDIRECT'
             && $status_code === 'REDIRECT'
        ) {
            $redirect_url = $processor->create_3ds_redirect_page( $api_response );

            $result->set_status( 'success' );
            $result->set_payment_details( [ 'redirect' => $redirect_url ] );
            $result->set_redirect_url( $redirect_url );

            $order->add_order_note(sprintf(
                __('Redirect initiated for payment (Transaction ID: %s)', 'custom-card-payment'),
                $api_response['trans_id'] ?? 'N/A'
            ));

            $order->update_status( 'pending', 'Redirect required for payment' );
            return;
        }

        // --- Successful Purchase ---
        if ( $result_code == 'SUCCESS' && in_array( $status_code, [ 'SETTLED', 'SUCCESS' ], true ) ) {
            // 2a) Mark the order complete in WC
            $order->payment_complete( $api_response['trans_id'] ?? '' );

            // 2b) Tell Blocks “go to order received”
            $result->set_status( 'success' );
            $result->set_redirect_url( $order->get_checkout_order_received_url() );
            $order->update_status( 'processing', 'order processed' );

            return;

        }

        // --- Declined ---
        if ( $result_code === 'DECLINED' && $status_code === 'DECLINED' ) {
            $order->update_status( 'failed', 'Payment declined by gateway' );

            $result->set_status( 'error' );
            $result->set_payment_details( [
                'error' => 'Your payment was declined. Please try a different card or contact your bank.',
            ] );
            $order->update_status( 'failed', 'order payment failed' );


            throw new Exception( 'Payment declined by gateway.' );

        }

        // --- Pending (authorized but not settled) ---
        if ( $result_code === 'SUCCESS' && $status_code === 'PENDING' ) {
            $order->update_status( 'pending', 'Payment authorized; awaiting settlement' );

            $result->set_status( 'success' );
            $result->set_redirect_url( $order->get_checkout_order_received_url() );
            return;
        }

        // --- Fallback: unexpected response ---
        $order->update_status( 'failed', 'Unexpected payment response' );
        $result->set_status( 'error' );
        $result->set_payment_details( [
            'error' => 'Payment failed due to an unexpected response.',
        ] );
        throw new Exception( 'Unexpected payment response.' );

    } catch ( Exception $e ) {
        // Log the exception
        $logger->error( 'Gateway exception: ' . $e->getMessage(), ['source' => 's2s-payment'] );

        // Ensure Blocks sees a failure
        $result->set_status( 'error' );
        $result->set_payment_details( [
            'error' => $e->getMessage(),
        ] );

        // Let WP catch & display the error
        throw $e;
    }
}



add_action('template_redirect', function() {
    // Check if we are handling the payment callback.
    if (strpos($_SERVER['REQUEST_URI'], '/payment-handler') !== false) {

        // Debug mode: if a 3DS transient exists, output the form.
        if (isset($_GET['3ds_redirect'])) {
            $transient_key = sanitize_text_field($_GET['3ds_redirect']);
            $form = get_transient($transient_key);
            if (!$transient_key || !$form) {
                wp_die('Session expired or invalid.');
            }
            echo $form;
            exit;
        }
        
        // Retrieve callback parameters.
        $order_id = isset($_GET['order_id']) ? sanitize_text_field($_GET['order_id']) : '';
        $pa_req   = isset($_GET['pa_req']) ? sanitize_text_field($_GET['pa_req']) : '';

        if (empty($order_id)) {
            wp_die('Order ID is missing.');
        }
        
        $order = wc_get_order($order_id);
        if (!$order) {
            wp_die('Order not found.');
        }
        
        // Check if the returned PaReq indicates a decline.
        if (!empty($pa_req) && strpos($pa_req, 'DECLINE') === 0) {
            // Log the decline event.
            $logger = wc_get_logger();
            $logger->error('3DS Authentication failed: PaReq indicates DECLINE for order ' . $order_id, ['source' => 's2s-payment']);

            // Mark the order as failed and add an order note.
           
            
            // Redirect to the order-received page with a query parameter to display the error.
            $thankyou_url  = wc_get_endpoint_url('order-received', $order->get_id(), wc_get_page_permalink('checkout'));
            $thankyou_url  = add_query_arg(array(
                'key'       => $order->get_order_key(),
                'payment'   => 'declined'
            ), $thankyou_url);
            wp_redirect($thankyou_url);
            exit;
        }

        


        // Build the thank you (order-received) URL.
        $thankyou_url  = wc_get_endpoint_url('order-received', $order->get_id(), wc_get_page_permalink('checkout'));
        $thankyou_url  = add_query_arg('key', $order->get_order_key(), $thankyou_url);
        wp_redirect($thankyou_url);
        exit;
    }
});




add_action('woocommerce_thankyou', function($order_id) {
    if (isset($_GET['payment']) && $_GET['payment'] === 'declined') {
        echo '<div class="woocommerce-error" style="margin:20px 0;">Your order ' . $order_id . ' is received but your payment was declined. Please try a different card or contact your bank.</div>';
    }
});