<?php

if (!class_exists('WC_Payment_Gateway')) {
    return;
}

abstract class WC_Abstract_Custom_Gateway extends WC_Payment_Gateway
{
    public function __construct()
    {
        $this->init_base_properties();
        $this->init_form_fields();
        $this->init_settings();

        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');
        $this->enabled = $this->get_option('enabled');

        add_action(
            'woocommerce_update_options_payment_gateways_' . $this->id,
            [$this, 'process_admin_options']
        );
        add_action('woocommerce_api_wc_montypay_callback', array($this, 'check_ipn_response'));
    }

    protected function init_base_properties()
    {
        $this->has_fields = false;
    }

    public function init_form_fields()
    {
        $this->form_fields = [
            'enabled' => [
                'title'   => __('Enable/Disable', 'custom-card-payment'),
                'type'    => 'checkbox',
                'label'   => __('Enable this payment method', 'custom-card-payment'),
                'default' => 'no'
            ],
            'merchant_key' => [
                'title'       => __('Merchant Key', 'custom-card-payment'),
                'type'        => 'text',
                'description' => __('Provided by your payment gateway', 'custom-card-payment'),
                'desc_tip'    => true,
            ],
            'merchant_pass' => [
                'title'       => __('Merchant Password', 'custom-card-payment'),
                'type'        => 'password',
                'description' => __('Provided by your payment gateway', 'custom-card-payment'),
                'desc_tip'    => true,
            ],

            'title' => [
                'title'       => __('Title', 'custom-card-payment'),
                'type'        => 'text',
                'default'     => __('Credit/Debit Card', 'custom-card-payment'),
                'desc_tip'    => true,
            ],
            'description' => [
                'title'       => __('Description', 'custom-card-payment'),
                'type'        => 'textarea',
                'default'     => __('Pay with your credit card', 'custom-card-payment'),
                'desc_tip'    => true,
            ]
        ];
    }

    public function check_ipn_response()
    {
        global $woocommerce;

        try {
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                header('HTTP/1.1 405 Method Not Allowed');
                exit;
            }

            // Parse input data
            $content_type = $_SERVER['CONTENT_TYPE'] ?? '';
            $raw_post = file_get_contents('php://input');
            $data = [];

            if (strpos($content_type, 'application/json') !== false) {
                $data = json_decode($raw_post, true);
            } else {
                parse_str($raw_post, $data);
            }

            $data = array_merge($data, $_POST);
            $logger = wc_get_logger();
            $logger->info(sprintf(
                'IPN hit for order %s at %s, payload: %s',
                $data['order_id'] ?? $data['order_number'],
                date('Y-m-d H:i:s'),
                json_encode($data)
            ), ['source' => 'montypay']);


            // Extract order ID
            $order_id = $data['order_id'] ?? $data['order_number'] ?? null;
            if (!$order_id) {
                header('HTTP/1.1 400 Bad Request');
                exit;
            }

            $order = wc_get_order($order_id);
            if (!$order) {
                header('HTTP/1.1 404 Not Found');
                exit;
            }

            // Set transaction ID
            if (!empty($data['trans_id'])) {
                $order->set_transaction_id($data['trans_id']);
            }

            // Normalize parameters
            $action = strtoupper($data['action'] ?? '');
            $result = strtoupper($data['result'] ?? '');
            $status = strtoupper($data['status'] ?? '');
            $type = strtoupper($data['type'] ?? '');

            // Handle payment statuses
            $current_status = $order->get_status();
            if (in_array($current_status, ['pending', 'waiting', 'failed', 'on-hold', 'processing'])) {

                // Successful payment
                if (($result === 'SUCCESS' && $action === 'SALE' && $status === 'SETTLED') ||
                    ($type === 'SALE' && $status === 'SUCCESS')
                ) {
                    $order->payment_complete();
                    $woocommerce->cart->empty_cart();
                    $order->update_status('processing', 'Payment successful');
                }
                // Declined or failed
                elseif ($status === 'DECLINED' && $action === 'SALE') {
                    $order->update_status('failed', $data['decline_reason'] ?? 'Declined');
                } elseif ($status === 'FAIL' && ($action === 'SALE' || $type === 'SALE')) {
                    $order->update_status('failed', $data['reason'] ?? 'Failed');
                }
                // Pending/Redirect
                elseif (
                    ($status === 'REDIRECT' && $status === 'WAITING')
                    || ($result === 'REDIRECT' && $action === 'SALE')
                ) {
                    $order->update_status('pending', 'Pending payment confirmation');
                }
            }

            // Handle refunds
            if ($current_status === 'processing' && $action === 'REFUND') {
                if ($status === 'SUCCESS') {
                    $order->update_status('refunded', 'Refund processed');
                } else {
                    $order->update_status('failed', $data['reason'] ?? 'Refund failed');
                }
            }


            // 1) Clear the “At-a-Glance” counts
            delete_transient('wc_admin_dashboard_counts');



            // 3) (Optional) Clear order-specific transients
            if (function_exists('wc_delete_shop_order_transients')) {
                wc_delete_shop_order_transients($order);
            }
            header('HTTP/1.1 200 OK');
            exit;
        } catch (Exception $e) {
            header('HTTP/1.1 500 Internal Server Error');
            exit;
        }
    }


    public function admin_options()
    {
        // 1. Dynamic Heading
        echo '<h3>' . esc_html($this->get_method_title()) . '</h3>';

        // 2. Hidden API URL (if you still need a picture endpoint)
        $api_url = add_query_arg('wc-api', 'wc_set_picture', home_url('/'));
        echo '<input type="hidden" id="wc_api_url" value="' . esc_url($api_url) . '">';

        // 3. Settings table
        echo '<table class="form-table">';
        $this->generate_settings_html();
        echo '</table>';

        // 4. Dynamic Callback URL
        $callback_url    = add_query_arg('wc-api', 'wc_montypay_callback', home_url('/'));
        echo '<p><strong>' . esc_html__('Callback Url:', 'woocommerce-gateway-wpgfull') . '</strong> '
            . esc_url($callback_url)
            . '</p>';
    }
}
