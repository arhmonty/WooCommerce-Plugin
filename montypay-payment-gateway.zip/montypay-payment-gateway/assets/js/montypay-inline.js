jQuery(function ($) {
  const gatewayId = WC_MontyPay.gateway_id;
  const ajaxUrl = WC_MontyPay.ajax_url;
  const checkoutUrl = wc_checkout_params.checkout_url;
  // Show or hide the Place Order button
  function togglePlaceOrderBtn() {
    const sel = $('input[name="payment_method"]:checked').val();
    if (sel === gatewayId) {
      $('#place_order').hide();
    } else {
      $('#place_order').show();
    }
  }

  // Insert the iframe HTML
  function injectIframe(url) {
    $('#montypay-iframe-container').html(
      '<iframe src="' + url + '" style="width:100%; height:600px; border:none;" allowfullscreen></iframe>'
    );
  }

  // Show an error in the iframe container
  function handleError(msg) {
    $('#montypay-iframe-container').html('<p style="color:red;">' + msg + '</p>');
    console.error('MontyPay inline error:', msg);
  }

  // Kick off WooCommerce AJAX checkout to regenerate URL, then pull it
  function loadIframe() {
    const $sel = $('input[name="payment_method"]:checked');
    if (!$sel.length || $sel.val() !== gatewayId) {
      return;
    }

    // Hide the button & show a loading indicator
    togglePlaceOrderBtn();
    $('#montypay-iframe-container').html('<p>Loading payment form…</p>');

    const $form = $('form.checkout');
    $form.block({ message: null, overlayCSS: { background: '#fff', opacity: 0.6 } });

    // 1) Run process_payment() to get fresh session URL
    console.log($form.serialize())
    $.post(checkoutUrl, $form.serialize(), function (result) {
      $form.unblock();

      if (result.result !== 'success') {
        handleError(result.messages || 'Checkout error');
        $(document.body).trigger('checkout_error', [result]);
        return;
      }

      // 2) Fetch the new iframe URL from session
      $.post(ajaxUrl, { action: 'get_montypay_iframe_url' })
        .done(function (resp) {
          if (resp.success && resp.data.url) {
            injectIframe(resp.data.url);
          } else {
            handleError('Could not load payment form.');
          }
        })
        .fail(function () {
          handleError('AJAX error loading payment form.');
        });

    }, 'json');
  }

  // Bindings:
  // 1) Page-load auto: if MontyPay is pre-checked, load iframe
  $(window).on('load', function () {
    setTimeout(loadIframe, 500);
  });

  // 2) When user selects MontyPay
  $(document.body).on('payment_method_selected', function () {
    togglePlaceOrderBtn();
    loadIframe();
  });

  // 3) Also toggle button on any change to other methods
  $(document.body).on('change', 'input[name="payment_method"]', togglePlaceOrderBtn);
});
