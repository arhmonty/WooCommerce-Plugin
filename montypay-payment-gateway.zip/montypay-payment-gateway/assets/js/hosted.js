// (() => {
//   const {
//     registerPaymentMethod,
//     decodeEntities,
//     getSetting,
//     createElement,
//   } = window.MyPluginUtils;





//   const settings1 = getSetting('hosted_card_gateway_data', {});
//   const label1 = decodeEntities(settings1.title) || 'Pay Online';

//   const Content1 = () => {
//     return createElement(
//       'div',
//       { className: 'custom-card-content' },
//       decodeEntities(settings1.description || ''),
//       createElement(
//         'div',
//         { className: 'MontyPayLogo' },
//         createElement('label', null, 'Powered By'),
//         createElement('img', { src: 'https://montypaydev.com/global_assets/images/MontyPayLogo.png', className: 'MontyPayLogo' })
//       )
//     );
//   };


//   const paymentMethod = {
//     name: 'hosted_card_gateway',
//     label: label1,
//     content: createElement(Content1),
//     edit: createElement(Content1),
//     ariaLabel: label1,
//     canMakePayment: () => true,
//     supports: {
//       features: settings1.supports || ['products'],
//     },
//     createPayment: () => {
//       // This function should return a promise that resolves with payment data
//       return {
//         paymentMethodData: {
//           // Include any necessary data here
//         },
//       };
//     },
//   };
//   registerPaymentMethod(paymentMethod);
// })();

; (function () {
  const {
    registerPaymentMethod,
    decodeEntities,
    getSetting,
    createElement,
  } = window.MyPluginUtils;

  const settings1 = getSetting('hosted_card_gateway_data', {});
  const label1 = decodeEntities(settings1.title) || 'Pay Online';
  // Utility to render an <img> icon
  function CardIcon({ src, alt }) {
    return createElement('img', {
      src,
      alt,
      style: {
        width: '36px',
        height: 'auto',
        marginRight: '4px',
        verticalAlign: 'middle',
      },
    });
  }

  // A small component that renders Visa, MC and AmEx side by side based on settings
  function CardIcons() {
    const icons = [];
    if (settings1.show_visa === 'yes') {
      icons.push(
        createElement(CardIcon, {
          src: 'https://cdn.shopify.com/shopifycloud/checkout-web/assets/c1.en/assets/visa.sxIq5Dot.svg',
          alt: 'Visa',
        })
      );
    }
    if (settings1.show_mastercard === 'yes') {
      icons.push(
        createElement(CardIcon, {
          src: 'https://cdn.shopify.com/shopifycloud/checkout-web/assets/c1.en/assets/master.CzeoQWmc.svg',
          alt: 'MasterCard',
        })
      );
    }
    if (settings1.show_amex === 'yes') {
      icons.push(
        createElement(CardIcon, {
          src: 'https://cdn.shopify.com/shopifycloud/checkout-web/assets/c1.en/assets/american_express.C3z4WB9r.svg',
          alt: 'AmEx',
        })
      );
    }
    return createElement(
      'span',
      { style: { display: 'inline-flex', alignItems: 'center' } },
      ...icons
    );
  }

  const Content1 = () => {
    return createElement(
      'div',
      { className: 'custom-card-content' },
      // Inject icons into your content block too
      createElement(
        'div',
        { style: { marginBottom: '8px' } },
        createElement(CardIcons)
      ),
      decodeEntities(settings1.description || ''),
      createElement(
        'div',
        { className: 'MontyPayLogo', style: { marginTop: '12px' } },
        createElement('label', null, 'Powered By'),
        createElement('img', {
          src: 'https://montypaydev.com/global_assets/images/MontyPayLogo.png',
          className: 'MontyPayLogo',
          style: { marginLeft: '4px', verticalAlign: 'middle' },
        })
      )
    );
  };

  const paymentMethod = {
    name: 'hosted_card_gateway',
    ariaLabel: label1,
    canMakePayment: () => true,
    supports: { features: settings1.supports || ['products'] },

    // Use a React element for the label so we can inject icons
    label: createElement(
      'span',
      null,
      createElement(
        'span',
        { style: { marginLeft: '8px', verticalAlign: 'middle' } },
        label1
      ),
      createElement(CardIcons),

    ),

    content: createElement(Content1),
    edit: createElement(Content1),

    createPayment: () => {
      // Return a promise (here we just resolve immediately)
      return Promise.resolve({
        paymentMethodData: {
          /* ... */
        },
      });
    },
  };

  registerPaymentMethod(paymentMethod);
})();


; (function () {
  const {
    getSetting,
  } = window.MyPluginUtils;
  const settings1 = getSetting('hosted_card_gateway_data', {});
  const iframe_enabled = settings1.iframe_enabled === 'yes';
  if (iframe_enabled) {
    // 1) Monkey-patch fetchIframeUrl to **not** show the iframe immediately
    function fetchIframeUrl() {
      return fetch(WC_MontyPay.ajax_url, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ action: 'get_montypay_iframe_url' })
      })
        .then(r => r.json())
        .then(resp => {
          if (resp.success && resp.data.url) {
            return resp.data.url;
          }
          throw new Error('No iframe URL');
        });
    }

    // 2) Show the modal with a countdown, then swap in the iframe
    function showCountdownModal() {
      let count = 3;

      // Create overlay
      const overlay = document.createElement('div');
      Object.assign(overlay.style, {
        position: 'fixed',
        top: 0, left: 0, right: 0, bottom: 0,
        background: 'rgba(0,0,0,0.6)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 9999,
      });

      // Create modal box
      const modal = document.createElement('div');
      Object.assign(modal.style, {
        position: 'relative',
        width: '90%',
        maxWidth: '800px',
        height: '80%',
        background: '#fff',
        borderRadius: '4px',
        overflow: 'hidden',
        boxShadow: '0 2px 10px rgba(0,0,0,0.2)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: '2em',
        color: '#333',
      });

      // Close button
      const close = document.createElement('button');
      close.textContent = '×';
      Object.assign(close.style, {
        position: 'absolute',
        top: '8px',
        right: '12px',
        fontSize: '24px',
        background: 'transparent',
        border: 'none',
        cursor: 'pointer',
      });
      close.addEventListener('click', () => document.body.removeChild(overlay));

      // Content container
      const content = document.createElement('div');
      content.textContent = `Loading payment in ${count}…`;

      // assemble
      modal.appendChild(close);
      modal.appendChild(content);
      overlay.appendChild(modal);
      document.body.appendChild(overlay);

      // Countdown
      const timer = setInterval(() => {
        count--;
        if (count > 0) {
          content.textContent = `Loading payment in ${count}…`;
        } else {
          clearInterval(timer);
          content.textContent = '';
          // Now fetch and insert the iframe
          fetchIframeUrl()
            .then(url => {
              const iframe = document.createElement('iframe');
              iframe.src = url;
              Object.assign(iframe.style, {
                width: '100%',
                height: '100%',
                border: '0'
              });
              modal.appendChild(iframe);
            })
            .catch(err => {
              content.textContent = 'Error loading payment.';
              console.error('[MontyPay] AJAX error:', err);
            });
        }
      }, 1000);
    }

    // 3) Watch for the button entering its loading state
    function watchButton() {
      const btn = document.querySelector(
        'button.wc-block-components-checkout-place-order-button'
      );
      if (!btn) return requestAnimationFrame(watchButton);

      const obs = new MutationObserver(records => {
        for (const rec of records) {
          if (
            btn.classList.contains('wc-block-components-checkout-place-order-button--loading') &&
            btn.querySelector('svg.wc-block-components-checkout-place-order-button__icon')
          ) {
            obs.disconnect();
            console.log('[MontyPay] Button loading — showing countdown modal');
            showCountdownModal();
            break;
          }
        }
      });
      obs.observe(btn, {
        attributes: true,
        attributeFilter: ['class', 'disabled'],
        childList: true,
        subtree: true
      });
    }

    // kick off
    console.log('[MontyPay] Setting up button-loading watcher…');
    watchButton();
  }
})();

