(function (global) {
    const { registerPaymentMethod } = wc.wcBlocksRegistry;
    const { decodeEntities } = wp.htmlEntities;
    const { getSetting } = wc.wcSettings;
    const { createElement, useState, useEffect } = wp.element;
  
    global.MyPluginUtils = {
      registerPaymentMethod,
      decodeEntities,
      getSetting,
      createElement,
      useState,
      useEffect,
    };
  })(window);
  
 