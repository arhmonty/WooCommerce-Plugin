(() => {
    const {
      registerPaymentMethod,
      decodeEntities,
      getSetting,
      createElement,
    } = window.MyPluginUtils;
  
  
 
  

const settings3 = getSetting('whish_card_gateway_data', {});
const label3 = createElement(
    'div',
    { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px' , width: '100%' } },
  
    decodeEntities(settings3.title || 'Pay using e-wallet'),
    createElement('img', {
        src: 'https://montypaydev.com/global_assets/images/WhishMoneyLogo.png',
        alt: 'Card icons',
        className: 'WhishLogo',
      }),
  );

const Content3 = () => {
    return createElement(
        'div',
        { className: 'custom-card-content' },
        decodeEntities(settings3.description || ''),
        createElement(
            'div',
            {className : 'MontyPayLogo'},
            createElement('label',null,'Powered By'),
            createElement('img', { src: 'https://montypaydev.com/global_assets/images/MontyPayLogo.png', className: 'MontyPayLogo' })
        )
    );
};


const paymentMethod = {
    name: 'whish_card_gateway',
    label: label3,
    content: createElement(Content3),
    edit: createElement(Content3),
    ariaLabel: settings3.title,
    canMakePayment: () => true,
    supports: {
        features: settings3.supports || ['products'],
    },
    createPayment: () => {
        // This function should return a promise that resolves with payment data
        return {
            paymentMethodData: {
                // Include any necessary data here
            },
        };
    },
};
registerPaymentMethod(paymentMethod);


})();