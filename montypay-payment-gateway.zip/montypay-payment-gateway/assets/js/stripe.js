(() => {
    const {
      registerPaymentMethod,
      decodeEntities,
      getSetting,
      createElement,
    } = window.MyPluginUtils;
  
  
 
  

const settings2 = getSetting('stripe_card_gateway_data', {});
const label2 = createElement(
    'div',
    { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px' , width: '100%' } },
  
    decodeEntities(settings2.title || 'Pay using Stripe Js'),
    createElement('img', {
        src: 'https://montypaydev.com/global_assets/images/visa-mastercard-apple-Gpay.png',
        alt: 'Card icons',
        style: { height: '30px' },
      }),
  );

const Content2 = () => {
    return createElement(
        'div',
        { className: 'custom-card-content' },
        decodeEntities(settings2.description || ''),
        createElement(
            'div',
            {className : 'MontyPayLogo'},
            createElement('label',null,'Powered By'),
            createElement('img', { src: 'https://montypaydev.com/global_assets/images/MontyPayLogo.png', className: 'MontyPayLogo' })
        )
    );
};


const paymentMethod = {
    name: 'stripe_card_gateway',
    label: label2,
    content: createElement(Content2),
    edit: createElement(Content2),
    ariaLabel: settings2.title,
    canMakePayment: () => true,
    supports: {
        features: settings2.supports || ['products'],
    },
    createPayment: () => {
        // This function should return a promise that resolves with payment data
        return {
            paymentMethodData: {
                // Include any necessary data here
            },
        };
    },
};
registerPaymentMethod(paymentMethod);


})();