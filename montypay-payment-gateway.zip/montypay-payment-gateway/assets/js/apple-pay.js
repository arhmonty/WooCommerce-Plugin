(() => {
    const {
      registerPaymentMethod,
      decodeEntities,
      getSetting,
      createElement,
    } = window.MyPluginUtils;

    const erudaJs = document.createElement('script');
  erudaJs.src = 'https://cdn.jsdelivr.net/npm/eruda';
  erudaJs.onload = () => eruda.init();
  document.head.appendChild(erudaJs);
  
    const settings = getSetting('apple_pay_gateway_data', {});
    const label = decodeEntities(settings.title) || 'Apple Pay';

  
    const getCartTotal = (props) => {
      if (props?.billing?.cartTotal.value) {
        return parseFloat(props.billing.cartTotal.value).toFixed(2);
      }
      // fallback if needed...
    };
  
    const handleApplePay = async (props) => {
      const amount = parseFloat(getCartTotal(props));
      if (amount <= 0) {
        alert('Cannot process payment: Cart total is invalid');
        return;
      }
    
      // 1) Create the session
      const session = new ApplePaySession(3, {
        countryCode:          settings.countryCode,
        currencyCode:         settings.currency,
        merchantCapabilities: ['supports3DS'],
        supportedNetworks:    settings.supportedNetworks,
        total: {
          label:  settings.storeName,
          amount: amount.toFixed(2),
        },
        merchantIdentifier:   settings.merchantIdentifier,
      });
    
      // 2) Merchant validation
      session.onvalidatemerchant = async (event) => {
        try {
          const res = await fetch(settings.validationEndpoint, {
            method:      'POST',
            headers:     { 'Content-Type': 'application/json' },
            credentials: 'include',
            body:        JSON.stringify({
              validationURL: event.validationURL,
              security:      settings.nonce,
            }),
          });
          if (!res.ok) {
            throw new Error(`HTTP error! status: ${res.status}`);
          }
    
          const body            = await res.json();
       
          // tell Apple “here’s your session” so it can show the sheet
          session.completeMerchantValidation(body);
        } catch (err) {
          console.error('Validation failed:', err);
          session.abort();                      // drop out of the flow
          alert('Apple Pay setup failed. Please try another method.');
        }
      };
    
      // 3) Payment authorization
      session.onpaymentauthorized = async (event) => {
        try {
          const res = await fetch(settings.processPaymentEndpoint, {
            method:  'POST',
            credentials: 'include',           // ← bring in the WooCommerce session cookie
            headers: { 'Content-Type': 'application/json' },
            body:    JSON.stringify({ paymentData: event.payment.token.paymentData })
          });
          const data = await res.json();
          
          if ( data.status === 'success' ) {
            session.completePayment( ApplePaySession.STATUS_SUCCESS );
            window.location.href = data.redirect_url;
          } else {
            session.completePayment( ApplePaySession.STATUS_FAILURE );
            alert( data.message || 'Payment failed' );
          }
        } catch (err) {
          console.error('Payment error:', err);
          session.completePayment( ApplePaySession.STATUS_FAILURE );
        }
      };
      
      
    
      // 4) Start the flow
      session.begin();
    };
    
    const montyLogo = createElement(
      'div',
      { className: 'MontyPayLogo' },
      createElement('label', null, 'Powered By'),
      createElement('img', {
        src: 'https://montypaydev.com/global_assets/images/MontyPayLogo.png',
        alt: 'MontyPay Logo',
        className: 'MontyPayLogo'
      })
    );
    const Content = (props) => {
      // 1) Device/User-agent checks
      const ua       = window.navigator.userAgent || '';
      const isIOS    = /iPhone|iPad|iPod/i.test(ua);
      const isMac    = /Macintosh/i.test(ua);
      const canPay   = window.ApplePaySession && ApplePaySession.canMakePayments();
    
      // 2) Decide which (if any) message to show
      let message = null;
      if (!isIOS) {
        message = 'Apple Pay is not supported on this device.';
      } else if (isMac) {
        message = 'Apple Pay is not supported on this device.';
      } else if (!canPay) {
        message = "You don’t have permission to make this payment.";
      }
    
      // 3) Render either the warning or the button
      return createElement(
        'div',
        { className: 'custom-card-content' },
        message
          ? createElement(
              'p',
              { className: 'apple-pay-warning' },
              message
            )
          : createElement(
              'button',
              {
                className: 'apple-pay-button',
                onClick: (e) => {
                  e.preventDefault();
                  handleApplePay(props);
                }
              },
            
            ),
            montyLogo
      );
    
    };
    
    registerPaymentMethod({
      name:       'apple_pay_gateway',
      label,
      content:    createElement(Content),
      edit:       createElement(Content),
      ariaLabel:  label,
      // only allow the method if device can actually launch Apple Pay
      canMakePayment: () => !!window.ApplePaySession && ApplePaySession.canMakePayments(),
      supports:   { features: settings.supports || ['products'] },
    });
    
  
    registerPaymentMethod({
      name:    'apple_pay_gateway',
      label,
      content: createElement(Content),
      edit    : createElement(Content),
      ariaLabel: label,
      canMakePayment: () => true,
      supports: { features: settings.supports || ['products'] },
    });
  })();
  
  