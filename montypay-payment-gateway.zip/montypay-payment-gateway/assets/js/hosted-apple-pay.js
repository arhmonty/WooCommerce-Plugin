(() => {
    const {
      registerPaymentMethod,
      decodeEntities,
      getSetting,
      createElement,
    } = window.MyPluginUtils;
  
  
 
  

const settings5 = getSetting('hosted_apple_pay_gateway_data', {});
const label5 = createElement(
    'div',
    { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px' , width: '100%' } },
  
    decodeEntities(settings5.title || 'Pay using hosted apple pay'),
    createElement('img', {
        src: 'https://montypaydev.com/global_assets/images/apple.png',
        alt: 'Card icons',
        style: { height: '30px' },
      }),
  );

const Content5 = () => {
    return createElement(
        'div',
        { className: 'custom-card-content' },
        decodeEntities(settings5.description || ''),
        createElement(
            'div',
            {className : 'MontyPayLogo'},
            createElement('label',null,'Powered By'),
            createElement('img', { src: 'https://montypaydev.com/global_assets/images/MontyPayLogo.png', className: 'MontyPayLogo' })
        )
    );
};


const paymentMethod = {
    name: 'hosted_apple_pay_gateway',
    label: label5,
    content: createElement(Content5),
    edit: createElement(Content5),
    ariaLabel: settings5.title,
    canMakePayment: () => true,
    supports: {
        features: settings5.supports || ['products'],
    },
    createPayment: () => {
        // This function should return a promise that resolves with payment data
        return {
            paymentMethodData: {
                // Include any necessary data here
            },
        };
    },
};
registerPaymentMethod(paymentMethod);


})();