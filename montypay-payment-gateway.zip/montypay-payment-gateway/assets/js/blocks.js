(() => {
  const {
    registerPaymentMethod,
    decodeEntities,
    getSetting,
    createElement,
    useState,
    useEffect
  } = window.MyPluginUtils;

const settings = getSetting('custom_card_gateway_data', {});
const label = decodeEntities(settings.title) || 'Credit Card';

const cardIcons = {
    visa: 'https://montypaydev.com/global_assets/images/visa.256x164.png',
    mastercard: 'https://montypaydev.com/global_assets/images/mastercard.256x161.png',
    union: 'https://montypaydev.com/global_assets/images/unionpay.256x163.png',
};
const defaultCardTypes = ['visa', 'mastercard'];
const cvvIconUrl = 'https://montypaydev.com/global_assets/images/cvv.png';

function formatCardNumber(number) {
    const digits = number.replace(/\D/g, '').substring(0, 16);
    return digits.replace(/(\d{4})(?=\d)/g, '$1 ');
}

function detectCardType(number) {
    const digits = number.replace(/\s/g, '');
    let type = '';
    if (/^4/.test(digits)) {
      type = 'visa';
    } else if (/^(5[1-5]|222[1-9]|22[3-9]\d|2[3-6]\d{2}|27[01]\d|2720)/.test(digits)) {
      type = 'mastercard';
    } else if (/^62/.test(digits)) {
      type = 'union';
    } else if (/^(34|37)/.test(digits)) {
      type = 'amex';
    }
    return type;
  }

function formatExpiryInput(raw) {
    let digits = raw.replace(/\D/g, '');
    if (digits.length === 0) return '';
    
    // Auto-correct first digit
    if (digits.length === 1 && parseInt(digits[0]) > 1) {
        digits = '0' + digits;
    }
    
    let month = digits.slice(0, 2);
    let remainder = digits.slice(2);
    
    // Auto-correct month
    if (month.length === 2) {
        const monthNum = parseInt(month, 10);
        if (monthNum > 12) {
            month = '0' + month[0];
            remainder = digits.slice(1);
        }
    }
    
    // Build formatted string
    let formatted = month;
    if (remainder.length > 0) {
        formatted += ' / ' + remainder.slice(0, 2);
    }
    
    return formatted;
}

function validateExpiry(expiry) {
    const cleaned = expiry.replace(/\D/g, '');
    if (cleaned.length !== 4) return 'Your card’s expiration date is incomplete.';

    const month = parseInt(cleaned.slice(0, 2), 10);
    const year = parseInt(cleaned.slice(2), 10);
    const currentYear = new Date().getFullYear() % 100;
    const currentMonth = new Date().getMonth() + 1;

    if (month < 1 || month > 12) return 'Invalid month , ';
    if (year < currentYear || (year === currentYear && month < currentMonth)) {
        return 'Your card’s expiration year is in the past.';
    }
    if (year > currentYear + 50) return 'Your card’s expiration year is invalid.';
    
    return '';
}

const CardFields = (props) => {
    const { eventRegistration, emitResponse } = props;
    const { onPaymentSetup } = eventRegistration;
    const [cardNumber, setCardNumber] = useState('');
    const [rawExpiry, setRawExpiry] = useState('');
    const [cvv, setCvv] = useState('');
    const [cardType, setCardType] = useState('');
    const [errors, setErrors] = useState({});

    useEffect(() => {
      const detected = detectCardType(cardNumber);
      setCardType(detected);
    }, [cardNumber]);

      // Mobile detection & rotating icon state
  const isMobile = typeof window !== 'undefined' && window.innerWidth <= 600;
  const [currentIcon, setCurrentIcon] = useState(defaultCardTypes[0]);

  useEffect(() => {
    if (!cardType && isMobile) {
      const interval = setInterval(() => {
        setCurrentIcon(prev => {
          const nextIndex = (defaultCardTypes.indexOf(prev) + 1) % defaultCardTypes.length;
          return defaultCardTypes[nextIndex];
        });
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [cardType, isMobile]);

    // Determine which icons to show
    let iconsToShow;
    if (cardType) {
      iconsToShow = [cardType];
    } else if (isMobile) {
      iconsToShow = [currentIcon];
    } else {
      iconsToShow = defaultCardTypes;
    }

    const handleExpiryChange = (e) => {
        const input = e.target.value;
        const digits = input.replace(/\D/g, '');
        const formatted = formatExpiryInput(digits);
        
        // Handle backspace properly
        if (input.endsWith(' / ')) {
            setRawExpiry(digits.slice(0, -1));
        } else {
            setRawExpiry(digits);
        }
        
        // Real-time validation
        if (digits.length === 4) {
            const error = validateExpiry(digits);
            setErrors(prev => ({ ...prev, expiry: error }));
        } else {
            setErrors(prev => ({ ...prev, expiry: null }));
        }
    };

    const handlePaymentSetup = async () => {
        const cardError = cardNumber.length < 15 ? 'Invalid card number' : null;
        const cvvError = cvv.length < 3 ? 'Invalid CVV' : null;
        const expiryError = validateExpiry(rawExpiry);

        const allErrors = {
            card: cardError,
            cvv: cvvError,
            expiry: expiryError
        };

        setErrors(allErrors);

        if (cardError || cvvError || expiryError) {
            return {
                type: emitResponse.responseTypes.ERROR,
                message: Object.values(allErrors).find(e => e) || 'Invalid payment details'
            };
        }

        return {
            type: emitResponse.responseTypes.SUCCESS,
            meta: {
                paymentMethodData: {
                    card_number: cardNumber.replace(/\s/g, ''),
                    expiry_date: formatExpiryInput(rawExpiry),
                    cvv: cvv
                }
            }
        };
    };

    useEffect(() => {
        const unsubscribe = onPaymentSetup(handlePaymentSetup);
        return unsubscribe;
    }, [cardNumber, rawExpiry, cvv]);

    return createElement(
        'div',
        { className: 'custom-card-fields' },
        // Top Row: Card Number and icons.
        createElement(
            'div', { className: 'card-number-row' },
            createElement('label', null, 'Card Number'),
            createElement('input', {
              type: 'text',
              value: formatCardNumber(cardNumber),
              onChange: e => {
                const value = e.target.value.replace(/\D/g, '').slice(0, 16);
                setCardNumber(value);
              },
              placeholder: '1234 1234 1234 1234',
              className: isMobile ? 'small-placeholder' : ''
            }),
            createElement(
              'div', { className: 'card-icon-container' },
              iconsToShow.map(typeName =>
                createElement('img', {
                  key: typeName,
                  src: cardIcons[typeName],
                  alt: typeName,
                  className: typeName === cardType ? 'active' : ''
                })
              )
            )
          ),
          // ...expiry and CVV rows as before...
          createElement('style', null,
            `@media (max-width: 600px) {
              .custom-card-fields input.small-placeholder::placeholder {
                font-size: 12px;
              }
            }`
          ),
        // Bottom Row
        createElement(
            'div',
            { className: 'custom-card-bottom-row' },
            createElement(
                'div',
                { className: 'form-row bottom-row-field' },
                createElement('label', null, 'Expiration Date'),
                createElement('input', {
                    type: 'text',
                    value: formatExpiryInput(rawExpiry),
                    onChange: handleExpiryChange,
                    placeholder: 'MM / YY',
                    style: errors.expiry ? { borderColor: '#d9534f' , color : 'red' } : {},
                    maxLength: 7,
                    className: isMobile ? 'small-placeholder' : ''
                }),
                errors.expiry && createElement('div', { className: 'payment-error' }, errors.expiry)
            ),
            createElement(
                'div',
                { className: 'form-row cvv-container bottom-row-field ' },
                createElement('label', null, 'Security Code'),
                createElement('input', {
                    type: 'text',
                    value: cvv,
                    onChange: e => setCvv(e.target.value.replace(/\D/g, '')),
                    placeholder: '123',
                    maxLength: 4,
                    style: errors.cvv ? { borderColor: '#d9534f' } : {},
                    className: isMobile ? 'small-placeholder' : ''
                }),
                createElement('img', { src: cvvIconUrl, className: 'cvv-icon' })
            ),
           
        ),
      
        createElement(
            'div',
            {className : 'MontyPayLogo'},
            createElement('label',null,'Powered By'),
            createElement('img', { src: 'https://montypaydev.com/global_assets/images/MontyPayLogo.png', className: 'MontyPayLogo' })
        ),
    );
};


const Content = (props) => {
    return createElement(
        'div',
        { className: 'custom-card-content' },
        decodeEntities(settings.description || ''),
        createElement(CardFields, props)
    );
};

const Label = (props) => {
    const { PaymentMethodLabel } = props.components;
    return createElement(PaymentMethodLabel, { text: label });
};

registerPaymentMethod({
    name: 'custom_card_gateway',
    label: createElement(Label),
    content: createElement(Content),
    edit: createElement(Content),
    ariaLabel: label,
    canMakePayment: () => true,
    supports: {
        features: settings.supports || ['products'],
    },
});
})();