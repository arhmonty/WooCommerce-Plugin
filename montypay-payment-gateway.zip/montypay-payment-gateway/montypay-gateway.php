<?php
/**
 * Plugin Name: Monty Pay Plugin
 * Description: Dynamically loads multiple WooCommerce payment gateways.
 * Author: Technical Team Monty Pay
 * Version: 4.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}


add_action('plugins_loaded', 'my_pg_load_gateways', 11);

function my_pg_load_gateways() {
    if (!class_exists('WC_Payment_Gateway')) {
        return;
    }

    $gateways_dir = plugin_dir_path(__FILE__) . 'gateways/';
    
    // First load payment processors
    foreach (glob($gateways_dir . '*/class-*-processor.php') as $processor_file) {
        require_once $processor_file;
    }

    // Then load gateway classes
    foreach (glob($gateways_dir . '*/class-wc-gateway-*.php') as $gateway_file) {
        require_once $gateway_file;
    }

    add_filter('woocommerce_payment_gateways', function ($methods) {
        foreach (glob(plugin_dir_path(__FILE__) . 'gateways/*/class-wc-gateway-*.php') as $file) {
            $class_name = get_class_name_from_file($file);
            if (class_exists($class_name)) {
                $methods[] = $class_name;
            }
        }
        return $methods;
    });
}

function get_class_name_from_file($file) {
    $contents = file_get_contents($file);
    // Match both abstract and concrete gateway implementations
    if (preg_match('/class\s+(\w+)\s+extends\s+(WC_Abstract_Custom_Gateway|WC_Payment_Gateway)/', $contents, $matches)) {
        return $matches[1];
    }
    return null;
}

// Register Blocks
add_action('woocommerce_blocks_payment_method_type_registration', function ($registry) {
    foreach (glob(plugin_dir_path(__FILE__) . 'gateways/*/class-wc-*-blocks.php') as $block_file) {
        require_once $block_file;
        $class_name = get_class_name_from_file_block($block_file);
        if (class_exists($class_name)) {
            $registry->register(new $class_name());
        }
    }
});

function get_class_name_from_file_block($file) {
    $contents = file_get_contents($file);
    if (preg_match('/class\s+(\w+)\s+extends\s+AbstractPaymentMethodType/', $contents, $matches)) {
        return $matches[1];
    }
    return null;
}

// Optional: Processor class validation
function get_processor_class_from_file($file) {
    $contents = file_get_contents($file);
    if (preg_match('/class\s+(\w+_Processor)\b/', $contents, $matches)) {
        return $matches[1];
    }
    return null;
}